/**
 * finding_filesystems
 * CS 241 - Fall 2021
 */
#include "minixfs.h"
#include "minixfs_utils.h"
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h> 
#include <string.h>
#include <math.h>
#define MIN(x, y) (x < y ? x : y)
#define MAX(x, y) (x > y ? x : y)
/**
 * Virtual paths:
 *  Add your new virtual endpoint to minixfs_virtual_path_names
 */
char *minixfs_virtual_path_names[] = {"info", /* add your paths here*/};

/**
 * Forward declaring block_info_string so that we can attach unused on it
 * This prevents a compiler warning if you haven't used it yet.
 *
 * This function generates the info string that the virtual endpoint info should
 * emit when read
 */
static char *block_info_string(ssize_t num_used_blocks) __attribute__((unused));
static char *block_info_string(ssize_t num_used_blocks) {
    char *block_string = NULL;
    ssize_t curr_free_blocks = DATA_NUMBER - num_used_blocks;
    asprintf(&block_string,
             "Free blocks: %zd\n"
             "Used blocks: %zd\n",
             curr_free_blocks, num_used_blocks);
    return block_string;
}

// Don't modify this line unless you know what you're doing
int minixfs_virtual_path_count =
    sizeof(minixfs_virtual_path_names) / sizeof(minixfs_virtual_path_names[0]);

int minixfs_chmod(file_system *fs, char *path, int new_permissions) {
    // Thar she blows!
    if (!fs || !path) {
	return -1;
    }
    inode* targ = get_inode(fs, path);
    // is in file
    if (!targ) {
	errno = ENOENT;
	return -1;
    }
    uint16_t mode = targ->mode;
    mode = mode >> RWX_BITS_NUMBER;
    mode = mode << RWX_BITS_NUMBER;
    mode += new_permissions;
    targ->mode = mode;   
    clock_gettime(CLOCK_REALTIME, &targ->ctim);

    return 0;
}

int minixfs_chown(file_system *fs, char *path, uid_t owner, gid_t group) {
    // Land ahoy!
    if (!fs || !path) {
	return -1;
    }
    inode* targ = get_inode(fs, path);
    if (!targ) {
	errno = ENOENT;
        return -1;
    }
    if (owner != (uid_t)-1) {
	targ->uid = owner;
    }
    if (group != (gid_t)-1) {
	targ->gid = group;
    }
    clock_gettime(CLOCK_REALTIME, &targ->ctim);
    return 0;
}

inode *minixfs_create_inode_for_path(file_system *fs, const char *path) {
    // Land ahoy!

    const char* filename = NULL;
    inode* parent = parent_directory(fs, path, &filename);
    if (!valid_filename(filename)) {
	return NULL;
    }
    
    inode* test = get_inode(fs, path);
    // is in file
    if (test) {
	clock_gettime(CLOCK_REALTIME, &test->ctim);
	return NULL;
    }

    inode_number i = first_unused_inode(fs);
    if (i < 0) {
	return NULL;
    }
    
    inode* this = fs->inode_root + i;
    init_inode(parent, this);
    
    int index = 0;
    int used_block = parent->size / sizeof(data_block);
    int offset = parent->size % sizeof(data_block);
    
    if (used_block < NUM_DIRECT_BLOCKS ) {
    	//use direct block
	if (offset == 0) {
	    index = add_data_block_to_inode(fs, parent);
	    if (index == -1) {
		return NULL;
	    }
	} else {
	    index = parent->direct[used_block];
	}
    } else {
	//use undirect block
	int result = add_single_indirect_block(fs, parent);
	if (result != 0) {
           return NULL;
	}
	data_block_number *block_array = (data_block_number *)(fs->data_root + parent->indirect);
	if (offset == 0) {
	    index = add_data_block_to_indirect_block(fs, block_array);
	    if (index == -1) {
		return NULL;
	    }
	} else {
	    if (used_block - (int)NUM_DIRECT_BLOCKS > (int)NUM_INDIRECT_BLOCKS) {
	        return NULL;
	    }
	    index = block_array[used_block - NUM_DIRECT_BLOCKS];
	}
    }

    parent->size += FILE_NAME_ENTRY;
    minixfs_dirent dirent;
    dirent.name = (char*)filename; 
    dirent.inode_num = i;
    
    char* toAdd = (fs->data_root + index)->data + offset;
    make_string_from_dirent(toAdd, dirent);
    clock_gettime(CLOCK_REALTIME, &parent->ctim);
    return this;
}

ssize_t minixfs_virtual_read(file_system *fs, const char *path, void *buf,
                             size_t count, off_t *off) {
    if (!strcmp(path, "info")) {
        // TODO implement the "info" virtual file here
	char* map = GET_DATA_MAP(fs->meta);
	ssize_t used_block = 0;
	size_t i;
	for (i = 0; i < fs->meta->dblock_count; i++) {
	    if (map[i] == 1) {
		used_block++;
	    }
	}
	char* info = block_info_string(used_block);
	if (*off >= (int)strlen(info)) {
	    return 0;
	}
	size_t need_read = MIN((int)count, (int)strlen(info) - *off);
	memcpy(buf, info + *off, need_read);
	*off += need_read;
	return need_read;
    }

    errno = ENOENT;
    return -1;
}

ssize_t minixfs_write(file_system *fs, const char *path, const void *buf,
                      size_t count, off_t *off) {
    // X marks the spot
    size_t w_size = count;
    size_t start_w = *off;
    size_t end_size = w_size + start_w;
    if (end_size > (NUM_DIRECT_BLOCKS + NUM_INDIRECT_BLOCKS) * sizeof(data_block)) {
	errno = ENOSPC;
	return -1;
    }
    int num = ceil((double)(end_size) / sizeof(data_block));
    if (minixfs_min_blockcount(fs, path, num) == -1){
	errno = ENOSPC;
	return -1;
    }
    inode* this = get_inode(fs, path);
    ssize_t add_count = 0;
    while(add_count < (ssize_t)w_size) {
        int index = 0;
        int used_block = start_w / sizeof(data_block);
        int offset = start_w % sizeof(data_block);
        if (used_block < NUM_DIRECT_BLOCKS ) {
	    index = this->direct[used_block];
        } else {
	    data_block_number *block_array = (data_block_number *)(fs->data_root + this->indirect);
	    index = block_array[used_block - NUM_DIRECT_BLOCKS];
        }

	void* to_add = (fs->data_root + index)->data + offset;
	size_t add = MIN(sizeof(data_block), w_size - add_count);
        add_count += add;
	memcpy(to_add, buf, add);
	buf += add;
	start_w += add;	
    }
    *off += add_count;
    this->size += add_count;
    clock_gettime(CLOCK_REALTIME, &this->mtim);
    clock_gettime(CLOCK_REALTIME, &this->atim);
    return add_count;
}

ssize_t minixfs_read(file_system *fs, const char *path, void *buf, size_t count,
                     off_t *off) {
    const char *virtual_path = is_virtual_path(path);
    if (virtual_path)
        return minixfs_virtual_read(fs, virtual_path, buf, count, off);
    // 'ere be treasure!
    size_t start_read = *off;
    inode* this = get_inode(fs, path);
    if (!this) {
	errno = ENOENT;
	return -1;
    }
    if (start_read > this->size) {
	return 0;
    } 
    void* temp = buf;
    ssize_t read_count = 0;
    int need_read = MIN(count, this->size - start_read);
    while(read_count < (ssize_t)need_read) {
        int index = 0;
        int start_block = start_read / sizeof(data_block);
        int offset = start_read % sizeof(data_block);
        if (start_block < NUM_DIRECT_BLOCKS ) {
	    index = this->direct[start_block];
        } else {
	    data_block_number *block_array = (data_block_number *)(fs->data_root + this->indirect);
	    index = block_array[start_block - NUM_DIRECT_BLOCKS];
        }
               
	void* to_read = (fs->data_root + index)->data + offset;
	size_t read = MIN(sizeof(data_block), (size_t)need_read - read_count);
	read_count += read;
	memcpy(temp, to_read, read);
	temp += read;
	start_read += read;
	index++;
    }
    *off += read_count;
    clock_gettime(CLOCK_REALTIME, &this->atim);
 
    return read_count;
}
