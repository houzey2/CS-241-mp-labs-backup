/**
 * nonstop_networking
 * CS 241 - Fall 2021
 */
#include <stdio.h>
#include "format.h"
#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <signal.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include "common.h"
#include <sys/epoll.h>
#include "includes/dictionary.h"
#include "includes/vector.h"
#include <fcntl.h>
#define MAX_CLIENTS 1024
#include <sys/stat.h>
#include "includes/set.h"
static int socket_fd;
static int epfd;

static dictionary *client_map;
static set *file_set;
static char* dir_temp;
static int endSession;

#define MIN(x, y) (x < y ? x : y)
#define MAX(x, y) (x > y ? x : y)
#define BAD_REQUEST 0
#define BAD_SIZE 1
#define NO_FILE 2
typedef struct info {
    int status;			//phased(1) or not(0) or finished(2)
    verb command;		//command
    size_t size;
    char filename[1024];	//filename from command
    int error; 			// 0: bad request 1: bad file size; 2: no such file, -1 no error
} info;

void remove_epoll(int fd) {
    //LOG("remove");
    info* info = dictionary_get(client_map, &fd);
    epoll_ctl(epfd, EPOLL_CTL_DEL, fd, NULL);
    dictionary_remove(client_map, &fd);
    free(info);
    shutdown(fd, SHUT_WR);
    shutdown(fd, SHUT_RD);
    close(fd);
    //
    LOG("LOG: removed epoll");
}

void close_server(){
    LOG("LOG: close_server");
    endSession = 1;
    // add any additional flags here you want.
    if (shutdown(socket_fd, SHUT_RDWR) != 0) {
        //LOG("shutdown():");
    }
    close(socket_fd);
    dictionary_destroy(client_map);
    vector* file_list = set_elements(file_set);
    for(size_t i = 0; i < vector_size(file_list); i++) {
	char* file = vector_get(file_list, i);
	char buffer[1024];
	memset(buffer, 0, 1024);
	sprintf(buffer, "%s/%s", dir_temp, file);
	unlink(buffer);
	remove(buffer);
    }
    remove(dir_temp);
    vector_destroy(file_list);
    set_destroy(file_set);
    exit(0);
}
void change_write_epoll(int fd){
    struct epoll_event event;
    memset(&event, 0, sizeof(struct epoll_event));
    event.events = EPOLLOUT;  // EPOLLIN==read, EPOLLOUT==write
    event.data.fd = fd;
    epoll_ctl(epfd, EPOLL_CTL_MOD, fd, &event);
    
}
void handle_error(int fd) {
        info* info = dictionary_get(client_map, &fd);
    	write_all_to_socket(fd, "200\n", 4); 
	if (info->error == BAD_REQUEST) {
	    ssize_t count = write_all_to_socket(fd, err_bad_request, strlen(err_bad_request));    
	    LOG("LOG: err_bad_request");
	    if (count < (ssize_t)strlen(err_bad_request)) {
	        LOG("LOG: not enough space");   
	    }
	} else if (info->error == BAD_SIZE) {
	    ssize_t count = write_all_to_socket(fd, err_bad_file_size, strlen(err_bad_file_size));
	    LOG("LOG: err_bad_file_size");
	    if (count < (ssize_t)strlen(err_no_such_file)) {
		LOG("LOG: not enough space");
	    }
	} else if (info->error == NO_FILE) {
	    ssize_t count = write_all_to_socket(fd, err_no_such_file, strlen(err_no_such_file));
	    LOG("LOG: err_no_such_file");
	    if (count < (ssize_t)strlen(err_no_such_file)) {
		//LOG("not enough space");
	    }
	}
	//LOG("error");
	remove_epoll(fd);

}
void list(int fd){
    LOG("LOG: list");
    info* info = dictionary_get(client_map, &fd);
    write_all_to_socket(fd, "OK\n", strlen("OK\n"));
    vector* file_list = set_elements(file_set);
    size_t size = 0;
    for(size_t i = 0; i < vector_size(file_list); i++) {
	char* file = vector_get(file_list, i);
	size += strlen(file);
	size++;
    }
    write_all_to_socket(fd, (const char*)&size, sizeof(size_t));
    for(size_t i = 0; i < vector_size(file_list); i++) {
	char* file = vector_get(file_list, i);
	write_all_to_socket(fd, file, strlen(file));
	if (i != vector_size(file_list) - 1) {
	    write_all_to_socket(fd, "\n", strlen("\n"));
	} else {
	    write_all_to_socket(fd, "\0", 1);
	}
    }
    info->status = 2;
    remove_epoll(fd);
}

void get(int fd) {
    LOG("LOG: get");
    info* info = dictionary_get(client_map, &fd);
    char path[1024];
    memset(path, 0, 1024);
    sprintf(path, "%s/%s", dir_temp, info->filename); 
    struct stat attrib;
    int state = stat(path, &attrib);
    if (state == -1) {
	info->error = NO_FILE;
	handle_error(fd);
	return;
    }
    size_t size = attrib.st_size;
    LOG("LOG: get size is %zu", size);
    FILE* to_read = fopen(path, "r");
    if (!to_read) {
	info->error = NO_FILE;
	handle_error(fd);
	return;
    }   
    ssize_t count = write_all_to_socket(fd, "OK\n", strlen("OK\n"));
    //size_t size = *(size_t*)dictionary_get(file_size, info->filename);
    count = write_all_to_socket(fd, (const char*) &size, sizeof(size_t)); 
    int write_count = 0;
    char buffer[1024];
    while((size_t)write_count < size) {;
	int read_size = MIN(size - write_count, 1024);
	LOG("LOG: read_size is %d", read_size);
        memset(buffer, 0, 1024);
	fread(buffer, 1, read_size, to_read);
	count = write_all_to_socket(fd, (const char*) buffer, read_size);
	//LOG("LOG: buffer is %s", buffer);
	write_count += read_size;
    }
    fclose(to_read);
    info->status = 2;
    remove_epoll(fd); 
}
void put(int fd) {
    LOG("LOG: put");
    info* info = dictionary_get(client_map, &fd);
    size_t size;
    ssize_t count = read_all_from_socket(fd, (char*)&size, sizeof(size_t));
    LOG("LOG: put size is %zu", size);
    LOG("LOG: file name is %s", info->filename);
    if (count != sizeof(size_t)) {
	info->error = BAD_REQUEST;
	change_write_epoll(fd);
	handle_error(fd);
	//LOG("incorrect read number: %zd\nshould be:%zu\n", count, sizeof(size_t));
	return;
    }
    //info->size = size;
    char path[1024];
    memset(path, 0, 1024);
    sprintf(path, "%s/%s", dir_temp, info->filename);
    FILE* to_write = fopen(path, "w");
    if (!to_write) {
        info->error = BAD_REQUEST;
	change_write_epoll(fd);
	handle_error(fd);
	return;
    }
    int read_count = 0;
    char buffer[1024];
    while((size_t)read_count < size) {
	//sleep(2);
	int write_size = MIN(size - read_count, 1024);
	//LOG("write size is %d\n", write_size);
        memset(buffer, 0, 1024);
	count = read_all_from_socket(fd, buffer, write_size);
	/*if (count != write_size) {
	    info->error = BAD_REQUEST;
	    fclose(to_write);
	    remove(info->filename);
	    change_write_epoll(fd);
	    handle_error(fd);
	    return;
	}*/
	fwrite(buffer, write_size, 1, to_write);
	read_count += count;
	//LOG("read is: \n%s", buffer);
	if (count == 0) {
	    break;
	}
    }
    char test[1024];
    memset(test, 0, 1024);
    LOG("LOG: count is %d", read_count);
    if (read_count < (int) size) {
 	//print_too_little_data();
	//fclose(to_write);
	remove(info->filename);
	info->error = BAD_SIZE;
	change_write_epoll(fd);
	handle_error(fd);
	LOG("LOG: to_little_finish");
	return;
   } else if ( read_all_from_socket(fd, test, 1)) {
        //print_received_too_much_data();
	//fclose(to_write);
	remove(info->filename);
	info->error = BAD_SIZE;
	change_write_epoll(fd);
	handle_error(fd);
	LOG("LOG: to_much_data_finish");
	return;
   }
   LOG("LOG: put sucess");
   set_add(file_set, info->filename);
   //size_t saved =  *(size_t*)dictionary_get(file_size, info->filename);
   //LOG("%s saved size is %zu", info->filename, saved);
   fclose(to_write);
   info->status = 2;
   change_write_epoll(fd);
   write_all_to_socket(fd, "OK\n", strlen("OK\n"));    
   remove_epoll(fd);
}
void delete(int fd) {
    LOG("LOG: delete");
    info* info = dictionary_get(client_map, &fd);
    char path[1024];
    memset(path, 0, 1024);
    sprintf(path, "%s/%s", dir_temp, info->filename);
    if (remove(path) < 0) {
	info->error = NO_FILE;
	handle_error(fd);
	return;
    }
    set_remove(file_set, info->filename);
    write_all_to_socket(fd, "OK\n", strlen("OK\n"));
    info->status = 2;
    remove_epoll(fd); 
}

void parse_head(int fd) {
    LOG("LOG: parse");
    info* info = dictionary_get(client_map, &fd);
    char header[1024];
    memset(header, 0, 1024);
    size_t count = 0;
    while (count < 1024) {
	ssize_t byte = read_all_from_socket(fd, header + count, 1);
	if (byte == 0 || count >= 512 ) {
	    // finename <= 255
	    info->error = BAD_REQUEST;
	    change_write_epoll(fd);
	    handle_error(fd);
	    return;
	} 
	//LOG("size of header is %s\n", header);
	if (header[strlen(header) - 1] == '\n') {
	    header[strlen(header) - 1] = '\0';
	    break;
	}
	count++;
    }
    vector* args = string_vector_create();
    const char s[2] = " ";
    char *token;
    token = strtok(header, s);
    while( token != NULL ) {
        vector_push_back(args, token);
        token = strtok(NULL, s);
    }
    if (strcmp(vector_get(args, 0), "LIST") == 0 && vector_size(args) == 1) {
	LOG("LOG: LIST");
	info->command = LIST;	
	//add_write_epoll(fd);
	info->status = 1;
	list(fd);
    } else if (strcmp(vector_get(args, 0), "GET") == 0 && vector_size(args) == 2) {
	LOG("LOG: GET");
	info->command = GET;
	strcpy(info->filename, header + 4);	
	change_write_epoll(fd);
	info->status = 1;
	get(fd);
    } else if (strcmp(vector_get(args, 0), "PUT") == 0 && vector_size(args) == 2) {
	LOG("LOG: PUT")
	info->command = PUT;
	strcpy(info->filename, header + 4);	
	//set_add(set_file, info->filename);
	info->status = 1;
	put(fd);
    } else if (strcmp(vector_get(args, 0), "DELETE") == 0 && vector_size(args) == 2) {
	LOG("LOG: DELETE");
	info->command = DELETE;
	strcpy(info->filename, header + 7);	
	//add_write_epoll(fd);
	info->status = 1;
	delete(fd);
    } else {
    	info->error = BAD_REQUEST;
	change_write_epoll(fd);
	handle_error(fd);
    }
    vector_destroy(args);
}

void check_state(int fd) {
    LOG("LOG: check_state");
    info* info = dictionary_get(client_map, &fd);
    if (!info) {
	//LOG("no_info");
	return;
    }
    if (info->error == -1) {
	//LOG("correct");
	if (info->status == 2) {
	    /*if (info->command == PUT) {
		LOG("put finished");
		ssize_t count = write_all_to_socket(fd, "OK\n", strlen("OK\n"));    
	        if (count < (ssize_t)strlen("OK\n")) {
	            LOG("not enough space");   
	        }
	    } 
	    remove_epoll(fd);*/
	} else if (info->status == 0) {
	    parse_head(fd);	
	} else {
	    if (info->command == LIST) {
		list(fd);
    	    } else if (info->command == GET) {
		get(fd);
    	    } else if (info->command == PUT) {
		put(fd);
    	    } else if (info->command == DELETE) {
   		put(fd);
    	    }
	}
    } else {

    }
}


void epoll_monitor() {
    LOG("LOG: epoll_monitor");
    epfd = epoll_create(1);
    if (epfd == -1) {
	LOG("LOG: epoll_create");
	exit(1);
    }
    struct epoll_event event;
    memset(&event, 0, sizeof(struct epoll_event));
    event.events = EPOLLIN;  // EPOLLIN==read, EPOLLOUT==write
    event.data.fd = socket_fd;
    epoll_ctl(epfd, EPOLL_CTL_ADD, socket_fd, &event);
    while(1) {
	struct epoll_event array[100];
	int num_events = epoll_wait(epfd, array, 100, 1000);
	if (num_events == -1) {
	    exit(1);
	}
	for (int i = 0; i < num_events; i++) {
	    if (array[i].data.fd == socket_fd) {
		//LOG("add");
		int conn_sock = accept(socket_fd, NULL, NULL);
		if (conn_sock == -1) {
		    //LOG("accept()");
		    exit(1);
		}
		
		//int flags = fcntl(conn_sock, F_GETFL, 0);
		//fcntl(conn_sock, F_SETFL, flags | O_NONBLOCK);
		
		struct epoll_event add;
		memset(&add, 0, sizeof(struct epoll_event));
		add.events = EPOLLIN | EPOLLET;
		add.data.fd = conn_sock;
		epoll_ctl(epfd, EPOLL_CTL_ADD, conn_sock, &add);
		
		info* new_info = malloc(sizeof(info));
		new_info->status = 0;
		new_info->command = V_UNKNOWN;
		memset(new_info->filename, 0, 1024);
		new_info->error = -1;
	    	dictionary_set(client_map, &conn_sock, new_info);
	    } else {
		//LOG("have");
	    	check_state(array[i].data.fd);
	    }
	}
    }    
}
void run_server(char *port) {
    //LOG("run_server");
    socket_fd = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK, 0);
    int option = 1;
    if (setsockopt(socket_fd, SOL_SOCKET, SO_REUSEADDR, (void *)&option, sizeof(option))) {
        //LOG("setsockopt()");
        exit(1);
    }    

    int s;
    struct addrinfo hints, *result;
    
    memset(&hints, 0, sizeof(struct addrinfo));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;

    s = getaddrinfo(NULL, port, &hints, &result);
    if (s != 0) {
	//fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s));
	exit(1);
    }
    if (bind(socket_fd, result->ai_addr, result->ai_addrlen) != 0) {
	//LOG("bind()");
	exit(1);
    } 
    if (listen(socket_fd, MAX_CLIENTS) != 0) {
	//LOG("listen()");
	exit(1);
    }
    freeaddrinfo(result);
    epoll_monitor();
}

void pipe_handler() {
    return;
}
int main(int argc, char **argv) {
    // good luck!
    if (argc < 2) {
	print_server_usage();
	exit(1);
    }
    
    struct sigaction act;
    memset(&act, '\0', sizeof(act));
    act.sa_handler = close_server;
    if (sigaction(SIGINT, &act, NULL) < 0) {
        return 1;
    }
    signal(SIGPIPE, pipe_handler);
    char template[] = "XXXXXX";
    dir_temp = mkdtemp(template);
    print_temp_directory(dir_temp);
    //LOG("create structors");
    
    
    client_map = int_to_shallow_dictionary_create();    
    file_set = string_set_create();
    run_server(argv[1]);
}
