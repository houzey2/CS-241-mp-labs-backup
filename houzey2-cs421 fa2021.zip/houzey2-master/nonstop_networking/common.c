/**
 * nonstop_networking
 * CS 241 - Fall 2021
 */
#include "common.h"
#include <arpa/inet.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

ssize_t read_all_from_socket(int socket, char *buffer, size_t count) {
    // Your Code Here
    ssize_t total_count = 0;
    while (total_count < (ssize_t)count) {
        int bytes = read(socket, buffer + total_count, count - total_count);
        if (bytes > 0) {
            total_count += bytes;
        } else if (bytes == 0) {
            break;
        } else {
            if (errno != EINTR) {
                return -1;
            }
        }
    }
    return total_count;
}

ssize_t write_all_to_socket(int socket, const char *buffer, size_t count) {
    // Your Code Here
    ssize_t total_count = 0;
    while (total_count < (ssize_t)count) {
        int bytes = write(socket, buffer + total_count, count - total_count);
        if (bytes > 0) {
            total_count += bytes;
        } else if (bytes == 0) {
            break;
        } else {
            if (errno != EINTR) {
                return -1;
            }
        }
    }
    return total_count;
}
