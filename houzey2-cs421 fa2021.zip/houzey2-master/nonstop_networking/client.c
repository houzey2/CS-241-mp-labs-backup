/**
 * nonstop_networking
 * CS 241 - Fall 2021
 */
#include "format.h"
#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <signal.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include "common.h"

#include <sys/stat.h>

#define MIN(x, y) (x < y ? x : y)
#define MAX(x, y) (x > y ? x : y)

char **parse_args(int argc, char **argv);
verb check_args(char **args);
int main(int argc, char **argv) {
    // Good luck!
    char** args = parse_args(argc, argv);
    verb command = check_args(args);
    struct addrinfo hints, *result;

    memset(&hints, 0, sizeof(struct addrinfo));
    
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    
    int s = getaddrinfo(args[0], args[1], &hints, &result);

    if (s != 0) {
	fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s));
	free(args);
	exit(1);
    }
    int sock_fd = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
    if (sock_fd == -1) {
	LOG("socket failed");
	free(args);
	exit(1);
    }
    int connect_result = connect(sock_fd, result->ai_addr, result->ai_addrlen);
    if (connect_result == -1) {
	LOG("connect failed");
	free(args);
	exit(1);
    }
    freeaddrinfo(result);

    // connected finished 
    // printf("connected!");
    // wrote
    if (command != LIST) {
	char arg_write[1024];
	memset(arg_write, 0, 1024);
	sprintf(arg_write, "%s %s\n", args[2], args[3]);
	//printf("size of arg_write is %zu\n", strlen(arg_write));
	ssize_t count = write_all_to_socket(sock_fd, (const char*) arg_write, strlen(arg_write));		
    	if (count < (ssize_t)strlen(arg_write)) {
	    LOG("not enough space");
	    free(args);
	    exit(1);
	}
	if (command == PUT) {
	// read file
	    struct stat attrib;
            int state = stat(args[4], &attrib);
	    if (state == -1) {
		free(args);
		exit(1);
	    }
	    size_t size = attrib.st_size;
	    LOG("sent size is %zu", size);
	    count = write_all_to_socket(sock_fd, (const char*) &size, sizeof(size_t));

	    //size_t size_test = 34114;
	    //count = write_all_to_socket(sock_fd, (const char*) &size_test, sizeof(size_t));
	    if (count < (ssize_t)sizeof(size_t)) {
	        LOG("not enough spacei");
	        free(args);
		exit(1);
	    }
	    
	    FILE* to_read = fopen(args[4], "r");
	    if (!to_read) {
		free(args);
		exit(1);
	    }
	    int write_count = 0;
	    while((size_t)write_count < size) {
		int read_size = MIN(size - write_count, 1024);
	    	char buffer[1024];
    	        memset(buffer, 0, 1024);
		fread(buffer, read_size, 1, to_read);
		count = write_all_to_socket(sock_fd, (const char*) buffer, read_size);
		if (count < read_size) {
		    LOG("not enough space");
		    fclose(to_read);
		    free(args);
		    exit(1);
		}
		write_count += read_size;
	    }
	    fclose(to_read);
	}
    } else if (command == LIST) {
	char arg_write[1024];
    	memset(arg_write, 0, 1024);
	sprintf(arg_write, "%s\n", args[2]);
	ssize_t count = write_all_to_socket(sock_fd, (const char*) arg_write, strlen(arg_write));		
    	if (count < (ssize_t)strlen(arg_write)) {
	    LOG("not enough space");
	    free(args);
	    exit(1);
	}
    }
    if (shutdown(sock_fd, SHUT_WR) != 0){
	LOG("write shut down");
	free(args);
	exit(1);
    }
    //read 
    //
    char response[1024];
    memset(response, 0, 1024);
    ssize_t count = read_all_from_socket(sock_fd, response, strlen("OK\n"));
    //printf("current response is %s\n", response);
    if (count > 0 && strcmp(response, "OK\n") == 0) {
	//printf("OK\n");
	if (command == GET) {
	   size_t size;
	   count = read_all_from_socket(sock_fd, (char*)&size, sizeof(size_t));
	   if (count < (ssize_t)sizeof(size_t)) {
	       LOG("not enough space");
	       free(args);
	       exit(1);
	   }
	   FILE* to_write = fopen(args[4], "w");
	   if (!to_write) {
	       free(args);
	       exit(1);
	   }
	   int read_count = 0;
	   while((size_t)read_count < size) {
		int write_size = MIN(size - read_count, 1024);
		char buffer[1024];
		count = read_all_from_socket(sock_fd, buffer, write_size);
		if (count < 0) {
		    LOG("error");
		    fclose(to_write);
		    free(args);
		    exit(1);
		}
		fwrite(buffer, write_size, 1, to_write);
		read_count += count;
		if (count == 0) {
		    break;
		}
	   }
	   fclose(to_write);
	   char test[1024];
	   memset(test, 0, 1024);
	   if (read_count < (int) size) {
		print_too_little_data();
	   } else if ( read_all_from_socket(sock_fd, test, 1024)) {
	        print_received_too_much_data();
	   }

	} else if (command == LIST) {
	   size_t size;
	   count = read_all_from_socket(sock_fd, (char*)&size, sizeof(size_t));
	   if (count < (ssize_t)sizeof(size_t)) {
	       LOG("not enough space");
	       free(args);
	       exit(1);
	   }
	   int read_count = 0;
	   while((size_t)read_count < size) {
		int write_size = MIN(size - read_count, 1024);
		char buffer[1024];
                memset(buffer, 0, 1024);
		count = read_all_from_socket(sock_fd, buffer, write_size);
		if (count < 0) {
		    LOG("error");
		    free(args); 	
		    exit(1);
		}
		printf("%s\n", buffer);
		read_count += count;
		if (count == 0) {
		    break;
		}
	   }
	   char test[1024];
	   memset(test, 0, 1024);
	   if (read_count < (int) size) {
		print_too_little_data();
	   } else if ( read_all_from_socket(sock_fd, test, 1024)) {
	        print_received_too_much_data();
	   }
	} else {
	    print_success();
	}
    } else {
	//LOG("error");
	char buffer[1024];
        memset(buffer, 0, 1024);
	count = read_all_from_socket(sock_fd, buffer, 3);
	while(1) {
	    count = read_all_from_socket(sock_fd, buffer, 1024);
	    if (count < 0) {
	        LOG("has error");
		free(args);
	        exit(1);
	    }
	    if (count == 0) {
	        break;
	    }
	    //LOG("%s",buffer);
	    print_error_message(buffer);
	    memset(buffer, 0, 1024);

	}
    }
    if (shutdown(sock_fd, SHUT_RD) != 0){
	LOG("read shut down");
	free(args);
	exit(1);
    }
    close(sock_fd);
    free(args);
    return 0;
}

/**
 * Given commandline argc and argv, parses argv.
 *
 * argc argc from main()
 * argv argv from main()
 *
 * Returns char* array in form of {host, port, method, remote, local, NULL}
 * where `method` is ALL CAPS
 */
char **parse_args(int argc, char **argv) {
    if (argc < 3) {
        return NULL;
    }

    char *host = strtok(argv[1], ":");
    char *port = strtok(NULL, ":");
    if (port == NULL) {
        return NULL;
    }

    char **args = calloc(1, 6 * sizeof(char *));
    args[0] = host;
    args[1] = port;
    args[2] = argv[2];
    char *temp = args[2];
    while (*temp) {
        *temp = toupper((unsigned char)*temp);
        temp++;
    }
    if (argc > 3) {
        args[3] = argv[3];
    }
    if (argc > 4) {
        args[4] = argv[4];
    }

    return args;
}

/**
 * Validates args to program.  If `args` are not valid, help information for the
 * program is printed.
 *
 * args     arguments to parse
 *
 * Returns a verb which corresponds to the request method
 */
verb check_args(char **args) {
    if (args == NULL) {
        print_client_usage();
        exit(1);
    }

    char *command = args[2];

    if (strcmp(command, "LIST") == 0) {
        return LIST;
    }

    if (strcmp(command, "GET") == 0) {
        if (args[3] != NULL && args[4] != NULL) {
            return GET;
        }
        print_client_help();
        exit(1);
    }

    if (strcmp(command, "DELETE") == 0) {
        if (args[3] != NULL) {
            return DELETE;
        }
        print_client_help();
        exit(1);
    }

    if (strcmp(command, "PUT") == 0) {
        if (args[3] == NULL || args[4] == NULL) {
            print_client_help();
            exit(1);
        }
        return PUT;
    }

    // Not a valid Method
    print_client_help();
    exit(1);
}
