/**
 * parallel_make
 * CS 241 - Fall 2021
 */
#include <stdio.h>
#include <stdlib.h>
#include "format.h"
#include "graph.h"
#include "parmake.h"
#include "parser.h"
#include "includes/vector.h"
#include "includes/set.h"
#include "includes/dictionary.h"
#include "includes/queue.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <ctype.h>
#include <pthread.h>
//can be optimized.
//
//
static dictionary* time_change = NULL;
static dictionary* results = NULL;
static size_t count = 0;
static queue* goal_child = NULL;
static graph* d_graph = NULL;
static dictionary* degrees = NULL;
static pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
static set* check_add = NULL;
int run_command(char *target) {
    rule_t * rule = (rule_t *)graph_get_vertex_value(d_graph, target);
    vector* commands = rule->commands;
    //printf("get command\n");
    size_t i;
    for(i = 0; i < vector_size(commands); i++) {
	const char* command = vector_get(commands, i);
	//printf("%s\n", command);

	int result = system(command);
	//printf("result is %d\n", result);
	if (result != 0) {
	    return 0;
	}
    }
    return 1;         
}
void set_prev(char* target) {
    //rule_t *rule = (rule_t *)graph_get_vertex_value(d_graph, target);
    //printf("set prev\n");
    vector *anti_neighbors = graph_antineighbors(d_graph, target);
    for (size_t j = 0; j < vector_size(anti_neighbors); j++) {
	char* anti = vector_get(anti_neighbors, j);
	if (!dictionary_contains(degrees, anti)) {
	    continue;
	}
	//printf("trying to get %s\n", anti);
	int anti_degree = *(int*)dictionary_get(degrees, anti);
	
	anti_degree -= 1;
	dictionary_set(degrees, anti, (void*)&anti_degree);
	if (anti_degree == 0) {
	    queue_push(goal_child, anti);
	    //printf("adding %s\n", anti);
	}
    }
    vector_destroy(anti_neighbors);
}
void* run_target(void* input) {	
    while(1) {
        char* cur_target = queue_pull(goal_child);	
	//printf("target is %s\n", cur_target);
	if (strcmp(cur_target, "") == 0) {
	    queue_push(goal_child, "");
	    return NULL;
	}
	int cur_result = 1;
	dictionary_set(results, cur_target, (void*)&cur_result);
	rule_t * rule = (rule_t *)graph_get_vertex_value(d_graph, cur_target);
	if (rule->state) {
	    //printf("%s is satisfied\n", rule->target);
	    pthread_mutex_lock(&m);
	    set_prev(cur_target);
	    pthread_mutex_unlock(&m);
	    continue;
	}
	vector *neighbors = graph_neighbors(d_graph, cur_target);
        for (size_t j = 0; j < vector_size(neighbors); j++) {
	    char *neighbor = vector_get(neighbors, j);
	    //printf("%s is finding neighbor %s\n", cur_target, neighbor);
	    size_t neighbor_result = *(int*)dictionary_get(results, neighbor);
	    //printf("%s has neighbor %s with result %zu\n", cur_target, neighbor,  neighbor_result);
	    cur_result = cur_result & neighbor_result;
	}

	if (cur_result != 1) {
	    pthread_mutex_lock(&m);
	    dictionary_set(results, cur_target, (void*)&cur_result);
	    vector_destroy(neighbors);
	    set_prev(cur_target);
	    pthread_mutex_unlock(&m);
	    continue;
	}
	//printf("run command\n");
	cur_result = cur_result & run_command(cur_target);
	pthread_mutex_lock(&m);
	set_prev(cur_target);
        dictionary_set(results, cur_target, (void*)&cur_result);
	rule->state = 1;
	pthread_mutex_unlock(&m);
        vector_destroy(neighbors);
    }
    return input;
}

void set_satisfy(queue *valid, char *target, set *visited) {
    //printf("setting satisfy, current target is %s\n", target);
    set_add(visited, target);
    rule_t *rule = (rule_t *)graph_get_vertex_value(d_graph, target);
    struct stat attrib;
    int state = stat(target, &attrib);	
    rule->state = state != -1;
    //printf("state is %d\n", rule->state);

    int cur_result = 1;
    dictionary_set(results, target, (void*)&cur_result);    
    
    dictionary_set(time_change, target, (void*)&attrib.st_mtime);
    vector *neighbors = graph_neighbors(d_graph, target);
    for (size_t i = 0; i < vector_size(neighbors); i++) {
	//printf("target: %s, index: %zu\n", target, i);
	char* neighbor = vector_get(neighbors, i);
	if (!set_contains(visited, neighbor)) {
            set_satisfy(valid, vector_get(neighbors, i), visited);
	}
	/*if (rule->state != 0) {
	    continue;
	}*/
	rule_t *depend = (rule_t *)graph_get_vertex_value(d_graph, neighbor);
	int newer = difftime(*(time_t*)dictionary_get(time_change, neighbor), *(time_t*)dictionary_get(time_change, target)) > 0;
	rule->state = (rule->state) & depend->state & !newer;
    } 
    int degree = graph_vertex_degree(d_graph, target);
    if (degree == 0) {
	if (!set_contains(check_add, target)) {
            queue_push(valid, target);
            count++;
	    set_add(check_add, target);
	}
    }
    dictionary_set(degrees, target, (void*)& degree);
    vector_destroy(neighbors);
    //printf("check end for %s\n", target);
}

void satification(queue *valid, char *target) {
    set *visited = string_set_create();
    set_satisfy(valid, target, visited);
    set_destroy(visited);
}

int check_cycle(set *visited, set *path, char *target) {
    if (!set_contains(visited, target)) {
	set_add(visited, target);
	set_add(path, target);
        vector *neighbors = graph_neighbors(d_graph, target);
	for (size_t i = 0; i < vector_size(neighbors); i++) {
	    //printf("target is %s, neighbor is %s\n", target, (char*)vector_get(neighbors, i)); 
            if (!set_contains(visited, vector_get(neighbors, i))){
		if (check_cycle(visited, path, vector_get(neighbors, i))) {	
		    vector_destroy(neighbors);
		    return 1;
		}
            } else if (set_contains(path, vector_get(neighbors, i))) {
		vector_destroy(neighbors);
		return 1;
	    }
	}
        vector_destroy(neighbors);
    }
    if (set_contains(path, target)) {
        set_remove(path, target);
    }
    return 0;
}

int isCyclic(char *target) {
    set *visited = string_set_create();
    set *path = string_set_create();
    int result = check_cycle(visited, path, target);
    set_destroy(visited);
    set_destroy(path);
    return result;
}

int parmake(char *makefile, size_t num_threads, char **targets) {
    // good luck!i
    d_graph = parser_parse_makefile(makefile, targets);
    vector *target_list = graph_neighbors(d_graph, "");
    set *valid_goal = string_set_create();
    size_t i;
    for(i = 0; i < vector_size(target_list); i++) {
	char* target = (char*) vector_get(target_list, i);
	int cyclic = isCyclic(target);
	if (cyclic) {
	    //printf("has cycle\n");
	    print_cycle_failure(target); 
	    graph_remove_edge(d_graph, "", target);
	    continue;
	} else {
	    set_add(valid_goal, target);
	}
	//printf("target is %s\n", target);	
    }
    //printf("check circly finished\n");
    vector_destroy(target_list);
    target_list = set_elements(valid_goal);
    //printf("set element end\n");
    time_change = string_to_int_dictionary_create();
    results = string_to_int_dictionary_create();
    degrees = string_to_int_dictionary_create();
    goal_child = queue_create(graph_vertex_count(d_graph));  
    check_add = string_set_create();
    int degree = graph_vertex_degree(d_graph, "");
    dictionary_set(degrees, "", (void*)& degree);    
    for (i = 0; i < vector_size(target_list); i++) {
	satification(goal_child, vector_get(target_list, i));
    }
    /*while(count > 0) {
	printf("leaves are %s\n", (char*)queue_pull(goal_child));
	count--;
    }*/
    if (count > 0){
	pthread_t threads[num_threads];
        for (i = 0; i < num_threads; i++) {
	    pthread_create(&threads[i], 0, run_target, NULL);
        }
        for(i = 0; i < num_threads; i++) {
	pthread_join(threads[i], NULL); 	
        }
    }
    dictionary_destroy(time_change);
    dictionary_destroy(results);
    dictionary_destroy(degrees);
    queue_destroy(goal_child);
    graph_destroy(d_graph);
    vector_destroy(target_list); 
    set_destroy(valid_goal);
    set_destroy(check_add);
    return 0;
}

