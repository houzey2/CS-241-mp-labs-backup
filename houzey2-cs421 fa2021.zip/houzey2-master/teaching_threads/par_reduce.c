/**
 * teaching_threads
 * CS 241 - Fall 2021
 */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include "reduce.h"
#include "reducers.h"
#include <pthread.h>

/* You might need a struct for each task ... */

/* You should create a start routine for your threads. */
// contributors: houzey2, youlyu2, tw17;
typedef struct arg_thread {
    int* list;
    size_t list_len;
    reducer reduce_func;
    int base_case;
} arg_thread;

void *start_routine(void *input_str) {
    if (input_str == NULL) {
	return NULL;
    }
    arg_thread* args = (arg_thread*)input_str;
    int* list = args->list;
    size_t list_len = args->list_len;
    reducer reduce_func = args->reduce_func;
    int base_case = args->base_case;
    int result = base_case;
    result = reduce(list, list_len, reduce_func, base_case);
    int* toReturn = calloc(sizeof(int), 1);
    *toReturn = result;
    return (void *)toReturn;
};

int par_reduce(int *list, size_t list_len, reducer reduce_func, int base_case,
               size_t num_threads) {
    /* Your implementation goes here */
    //for(size_t j = 0; j < list_len; j++) {
//	printf("%d\n", list[j]);
  //  }
    if (list_len < num_threads || num_threads < 2) {
	return reduce(list, list_len, reduce_func, base_case);
    }
    size_t size = (size_t)ceil((double)list_len / (double)num_threads);
    //printf("size is %zu\n", size);
    arg_thread* arguments[num_threads];
    pthread_t threads[num_threads];
    size_t i;
    for(i = 0; i < num_threads; i++) {
	arg_thread* arg = calloc(sizeof(arg_thread), 1);
	arg->list = list;
	if (i == num_threads - 1) {
	    arg->list_len = list_len - size * (num_threads - 1);
	} else{ 
	    arg->list_len = size;
	}
	arg->reduce_func = reduce_func;
	arg->base_case = base_case;
	//printf("has %zu digit\n", arg->list_len);
//	for(size_t j = 0; j < size; j++) {
	   // printf("%d", *(list+j));
	//}
//	printf("\n");
	list += size;
        pthread_create(&threads[i], 0, start_routine, (void*)arg);
        arguments[i] = arg;	
    }
    int result_list[num_threads];
    for(i = 0; i < num_threads; i++) {
	void* result;
	pthread_join(threads[i], &result);
        result_list[i] = *((int*)result);
//i	printf("result = %d\n", result_list[i]);
        free(result);
    }
    int output =  reduce(result_list, num_threads, reduce_func, base_case);
    for(i = 0; i < num_threads; i++) {
	free(arguments[i]);
    }
    return output;
}
