/**
 * deepfried_dd
 * CS 241 - Fall 2021
 */

// Contributors: tw17, houzey2, xuningh2, youlyu2, enxuhan2, tkimura4

#include <getopt.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#include "format.h"

#define NSEC_IN_SEC 1000000000

extern char *optarg;
extern int optind, opterr, optopt;

static int sigusr = 0;

void signal_handler() {
    sigusr = 1;
}

int main(int argc, char **argv) {
    // signal handler
    signal(SIGUSR1, signal_handler);

    // variables for flags
    int i_flag = 0, o_flag = 0, b_flag = 0, c_flag = 0, p_flag = 0, k_flag = 0;
    char *input_file = NULL, *output_file = NULL;
    size_t block_size = 512, block_count = 0, input_skip = 0, output_skip = 0;

    // get flags and necessary args
    int opt;
    while ((opt = getopt(argc, argv, "i:o:b:c:p:k:")) != -1) {
        switch (opt) {
            case 'i': /* '-i' */
                i_flag = 1;
                input_file = optarg;
                break;
            case 'o': /* '-o' */
                o_flag = 1;
                output_file = optarg;
                break;
            case 'b': /* '-b' */
                b_flag = 1;
                block_size = atol(optarg);
                break;
            case 'c': /* '-c' */
                c_flag = 1;
                block_count = atol(optarg);
                break;
            case 'p': /* '-p' */
                p_flag = 1;
                input_skip = atol(optarg);
                break;
            case 'k': /* '-k' */
                k_flag = 1;
                output_skip = atol(optarg);
                break;
            default: /* '?' */
                exit(1);
        }
    }

    // get start time
    struct timespec start_time;
    clock_gettime(CLOCK_REALTIME, &start_time);
    double start_time_in_sec = start_time.tv_sec + (double)start_time.tv_nsec / NSEC_IN_SEC;

    // file variables
    FILE *input = stdin, *output = stdout;

    // open input file
    if (i_flag) {
        input = fopen(input_file, "r");
        if (!input) {
            print_invalid_input(input_file);
            exit(1);
        }
    }

    // open output file
    if (o_flag) {
        // create one if not exist
        output = fopen(output_file, "a");
        if (!output) {
            print_invalid_output(output_file);
            exit(1);
        }
        fclose(output);

        // open with r+ for fseek
        output = fopen(output_file, "r+");
        if (!output) {
            print_invalid_output(output_file);
            exit(1);
        }
    }

    // set offset for input
    if (p_flag) {
        fseek(input, input_skip * block_size, SEEK_SET);
    }

    // set offset for output
    if (k_flag) {
        fseek(output, output_skip * block_size, SEEK_SET);
    }

    // variables for block count
    size_t full_in = 0, partial_in = 0, full_out = 0, partial_out = 0, total = 0, count = 0;
    char buffer[block_size];

    // begin transfer
    while (1) {
        // if signal has been received
        if (sigusr) {
            // get interrupt time
            struct timespec interrupt_time;
            clock_gettime(CLOCK_REALTIME, &interrupt_time);
            double end_time_in_sec = interrupt_time.tv_sec + (double)interrupt_time.tv_nsec / NSEC_IN_SEC;

            // print status report
            print_status_report(full_in, partial_in, full_out, partial_out, total, end_time_in_sec - start_time_in_sec);

            // set signal flag back
            sigusr = 0;
        }

        // clean buffer
        memset(buffer, 0, block_size);

        // read from input
        size_t bytes_read = fread(buffer, 1, block_size, input);
        if (bytes_read) {
            if (bytes_read == block_size) {
                full_in++;
            } else {
                partial_in++;
            }
        }

        // write to output
        size_t bytes_write = fwrite(buffer, 1, bytes_read, output);
        if (bytes_write) {
            if (bytes_write == block_size) {
                full_out++;
            } else {
                partial_out++;
            }
        }

        // update total
        total += bytes_read;

        // check count when necessary
        if (block_count) {
            count++;
            if (count == block_count) {
                break;
            }
        }

        // break if eof reached
        if (feof(input)) {
            break;
        }
    }

    // get end time
    struct timespec end_time;
    clock_gettime(CLOCK_REALTIME, &end_time);
    double end_time_in_sec = end_time.tv_sec + (double)end_time.tv_nsec / NSEC_IN_SEC;

    // print status report
    print_status_report(full_in, partial_in, full_out, partial_out, total, end_time_in_sec - start_time_in_sec);

    // close input file and output file
    fclose(input);
    fclose(output);

    return 0;
}
