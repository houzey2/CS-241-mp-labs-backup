/**
 * mini_memcheck
 * CS 241 - Fall 2021
 */
// contributors: houzey2, tkimura4, youlyu2;

#include "mini_memcheck.h"
#include <stdio.h>
#include <string.h>
#include "mini_memcheck.h"
meta_data *head;
size_t total_memory_requested;
size_t total_memory_freed;
size_t invalid_addresses;
meta_data *list_end() {
    meta_data *curr = head;
    while(curr->next != NULL) {
	curr = curr->next;
    }
    return curr;
}

void *mini_malloc(size_t request_size, const char *filename,
                  void *instruction) {
    // your code here
    if (request_size <= 0) {
	return NULL;    
    }
    meta_data *data = (meta_data*)malloc(sizeof(meta_data) + request_size);
    if (!data) {
	return NULL;
    }
    total_memory_requested += request_size;
    data->request_size = request_size;
    data->filename = filename;
    data->instruction = instruction;
    data->next = NULL;
    //printf("set finish\n");
    if (!head) {
	//printf("set head\n");
	head = data;
    } else {
        //printf("add more\n");
	meta_data *end = list_end();
	end->next = data;
    }
    //printf("size = %zu\n", data->request_size);
    return data + 1;
}

void *mini_calloc(size_t num_elements, size_t element_size,
                  const char *filename, void *instruction) {
    // your code here
    size_t request_size = num_elements * element_size;
    void* newmem = mini_malloc(request_size, filename, instruction);
    if (newmem == NULL) {
	return NULL;
    }
    memset(newmem, 0, num_elements * element_size);
    return newmem;
}

void *mini_realloc(void *payload, size_t request_size, const char *filename,
                   void *instruction) {
    // your code here
    if (payload == NULL) {
	void* newmem = mini_malloc(request_size, filename, instruction);
	return newmem;
    }
    if (request_size == 0) {
	mini_free(payload);    
	return payload;
    }
    meta_data*  curr = head;
    while(curr != NULL) {
	if (curr + 1 == payload) {
	    break;
	}
	curr = curr->next;
    }
    if (curr == NULL) {
	invalid_addresses += 1;
	return NULL;
    }
    if (curr->request_size == request_size) {
	return payload;
    }
    size_t origin_size = curr->request_size;
    curr = (meta_data* ) realloc(curr,request_size + sizeof(meta_data));
    if (curr == NULL) {
	return NULL;
    }
    curr->request_size = request_size;
    if (origin_size < request_size) {
	total_memory_requested += request_size - origin_size;
    }
    if (origin_size > request_size) {
	total_memory_freed += origin_size - request_size;
    }
    return curr + 1;
}

void mini_free(void *payload) {
    // your code here
    if (payload == NULL) {
	//invalid_addresses += 1;
	return;
    }
   
    //printf("not null\n");
    
    meta_data *curr = head;
    //printf("%d\n", head == NULL);
    
    if (curr + 1 == payload) {
	//free head 
        //puts("delete head");
	head = curr->next;
        total_memory_freed += curr->request_size;
	
	free(curr);
	curr = NULL;
    } else {
	//puts("delete other");
        while(curr != NULL) {
	    if ((curr->next) + 1 == payload) {
		break;
	    }
	    curr = curr->next;
	}
	if (curr == NULL) {
	    invalid_addresses += 1;
	    return;
	}
	meta_data *found = curr->next;
        //puts("get found");
        curr->next = found->next;
	//puts("next seted");
	total_memory_freed+=found->request_size;
        free(found);
	found = NULL;
    }
}
