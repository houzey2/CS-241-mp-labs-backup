/**
 * mini_memcheck
 * CS 241 - Fall 2021
 */
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // Your tests here using malloc and free
   
    setvbuf(stdout, NULL, _IONBF, 0);	
    
    void* array = malloc(50);
    void* array1 = malloc(60);
    void* array2 = calloc(10, 1);
    void* array3 = calloc(20, 1);
    array3 = realloc(array3, 40);
    array3 = realloc(array3, 10);
    //puts("melloc finish");
    free(array1);
    free(array2);
    free(array);
    free(array3);
    //`free(array1);
    //free(array);
    return 0;
}
