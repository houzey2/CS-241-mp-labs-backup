/**
 * deadlock_demolition
 * CS 241 - Fall 2021
 */
#include "libdrm.h"

#include <assert.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
drm_t* resource1;
drm_t* resource2;
int test=0;
void *proc1(){
    printf("\nThis is proc1 using rs1");
    pthread_t id = pthread_self();
    drm_wait(resource1, &id);
    printf("before Sleep \n");
        sleep(5);
        printf("\np1 trying to get rs2..."); 
        int sucess = drm_wait(resource2, &id);
            test++;
	if (sucess == 0) {
	    printf("\n p1 failed to get rs2");
	    //drm_post(resource1, &id);
	    return 0;
	}
        printf("\nproc1 got rs2!!");    
        drm_post(resource2, &id);   
    drm_post(resource1, &id);  
    printf("proc1 end\n");
    return 0;
}

void *proc2(){
    printf("\nThis is proc2 using rs2");
    pthread_t id = pthread_self();
    drm_wait(resource2, &id);
         printf("before Sleep \n");
        sleep(5);
        printf("\np2 trying to get rs1..."); 
        int sucess = drm_wait(resource1, &id);
            test++;
       	if (sucess == 0) {
	    printf("\n p2 failed to get rs1");
	    //drm_post(resource1, &id);
	    return 0;
	}
	printf("\nproc2 got rs1!!");    
        drm_post(resource1, &id);
    drm_post(resource2, &id);  
    printf("proc2 end\n");
    return 0;
 
}

int main() {
    
    pthread_t t1, t2;
    resource1 = drm_init();
    resource2 = drm_init();
    pthread_create(&t1, NULL, proc1, NULL);
    pthread_create(&t2, NULL, proc2, NULL);
    pthread_join(t1,NULL);  
    pthread_join(t2,NULL);
    printf("end\n");
    drm_destroy(resource1);
    drm_destroy(resource2);    
    return 0;
}
