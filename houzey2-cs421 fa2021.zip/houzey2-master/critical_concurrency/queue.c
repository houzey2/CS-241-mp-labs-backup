/**
 * critical_concurrency
 * CS 241 - Fall 2021
 */

// contributors: tw17, houzey2, tkimura4 xuningh2，youlyu2;

#include "queue.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>

/**
 * This queue is implemented with a linked list of queue_nodes.
 */
typedef struct queue_node
{
    void *data;
    struct queue_node *next;
} queue_node;

struct queue
{
    /* queue_node pointers to the head and tail of the queue */
    queue_node *head, *tail;

    /* The number of elements in the queue */
    ssize_t size;

    /**
     * The maximum number of elements the queue can hold.
     * max_size is non-positive if the queue does not have a max size.
     */
    ssize_t max_size;

    /* Mutex and Condition Variable for thread-safety */
    pthread_cond_t cv;
    pthread_mutex_t m;
};

queue *queue_create(ssize_t max_size)
{
    /* Your code here */
    if (max_size < 0)
    {
        return NULL;
    }

    struct queue *new_queue = malloc(sizeof(struct queue));
    if (!new_queue)
    {
        return NULL;
    }

    new_queue->head = NULL;
    new_queue->tail = NULL;
    new_queue->size = 0;
    new_queue->max_size = max_size;
    pthread_mutex_init(&new_queue->m, NULL);
    pthread_cond_init(&new_queue->cv, NULL);

    return new_queue;
}

void queue_destroy(queue *this)
{
    /* Your code here */
    if (!this)
    {
        return;
    }

    queue_node *curr = this->head;
    while (curr)
    {
        queue_node *temp = curr;
        curr = curr->next;
        free(temp);
        temp = NULL;
    }
    pthread_mutex_destroy(&this->m);
    pthread_cond_destroy(&this->cv);
    free(this);
    this = NULL;
}

void queue_push(queue *this, void *data)
{
    /* Your code here */
    pthread_mutex_lock(&this->m);

    while (this->max_size > 0 && this->size == this->max_size)
    {
        pthread_cond_wait(&this->cv, &this->m);
    }

    queue_node *new_node = malloc(sizeof(queue_node));
    if (!new_node)
    {
        return;
    }

    new_node->data = data;
    new_node->next = NULL;

    if (this->size)
    {
        this->tail->next = new_node;
        this->tail = new_node;
    }
    else
    {
        this->head = new_node;
        this->tail = new_node;
    }

    this->size++;

    if (this->size == 1)
    {
        pthread_cond_broadcast(&this->cv);
    }

    pthread_mutex_unlock(&this->m);
}

void *queue_pull(queue *this)
{
    /* Your code here */
    pthread_mutex_lock(&this->m);

    while (this->size == 0)
    {
        pthread_cond_wait(&this->cv, &this->m);
    }

    void *data = this->head->data;
    queue_node *temp = this->head;
    if (this->size == 1)
    {
        this->head = NULL;
        this->tail = NULL;
    }
    else
    {
        this->head = this->head->next;
    }
    free(temp);
    temp = NULL;

    this->size--;

    if (this->size == this->max_size - 1)
    {
        pthread_cond_broadcast(&this->cv);
    }

    pthread_mutex_unlock(&this->m);

    return data;
}

