/**
 * critical_concurrency
 * CS 241 - Fall 2021
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "semamore.h"

int main(int argc, char **argv) {
    printf("Please write tests in semamore_tests.c\n");
    return 0;
}
