/**
 * mapreduce
 * CS 241 - Fall 2021
 */
//contributors: houzey2. tw17, tkimura4, youlyu2, weixia3
#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
int main(int argc, char **argv) {
    // Create an input pipe for each mapper.

    // Create one input pipe for the reducer.

    // Open the output file.

    // Start a splitter process for each mapper.

    // Start all the mapper processes.

    // Start the reducer process.

    // Wait for the reducer to finish.

    // Print nonzero subprocess exit codes.

    // Count the number of lines in the output file.
    
    if (argc != 6) {
	print_usage();
	return 1;
    }
    size_t mapper_count = atoi(argv[5]);

    int fd_list[mapper_count][2] ;
    size_t i;
    for(i = 0; i < mapper_count; i++) {
        descriptors_add(fd_list[i][0]);
        descriptors_add(fd_list[i][1]);
	pipe(fd_list[i]);
    }

    int fd_reduce[2];
    descriptors_add(fd_reduce[0]);
    descriptors_add(fd_reduce[1]);
    pipe(fd_reduce);

    FILE *file_out = fopen(argv[2], "w");
    
    //printf("Start a splitter process for each mapper.\n");
    pid_t split_child[mapper_count];
    for(i = 0; i < mapper_count; i++) {
	pid_t pid = fork();
	split_child[i] = pid;
	if (pid < 0) {
	    return 1;
	} else if (pid == 0) {
	    close(fd_list[i][0]);
	    dup2(fd_list[i][1], 1);
	    char str[strlen(argv[5]) + 1];
	    sprintf(str, "%zu", i);
	    execl("./splitter", "./splitter", argv[1], argv[5], str, NULL);
	    exit(1);
	    //	    sprintf();
	}
    }
    //printf("Start all the mapper processes.\n");
    pid_t mapper_child[mapper_count];
    for(i = 0; i < mapper_count; i++) {
	close(fd_list[i][1]);
	pid_t pid = fork();
	mapper_child[i] = pid;
	if (pid < 0) {
	    return 1;
	} else if (pid == 0) {
	    dup2(fd_list[i][0], 0);
	    close(fd_reduce[0]);
	    dup2(fd_reduce[1], 1);
	    execl(argv[3], argv[3], NULL);
	    exit(1);
	}
    }

   close(fd_reduce[1]);
   //printf("Start the reducer process.\n");
   pid_t pid = fork(); 
   if (pid < 0) {
	return 1;
   } else if (pid == 0) {
        dup2(fd_reduce[0], 0);
	dup2(fileno(file_out), 1);
	execl(argv[4], argv[4], NULL);
	exit(1);
   }
   close(fd_reduce[0]);
   fclose(file_out);
   
   //printf("wait for split\n");   
   for (i = 0; i < mapper_count; i++) {
	int status;
	waitpid(split_child[i], &status, 0);
	if (status) {
	    print_nonzero_exit_status("./splitter", status);
	}
   }
   //printf("wait for mapper\n");
   for (i = 0; i < mapper_count; i++) {
	int status;
	waitpid(mapper_child[i], &status, 0);
	if (status) {
	    print_nonzero_exit_status(argv[3], status);
	}
   }
   //printf("Wait for the reducer to finish.\n");
   int status;
   waitpid(pid, &status, 0);
   if (status) {
	print_nonzero_exit_status(argv[4], status);
   }
   // printf("Count the number of lines in the output file.\n");
   print_num_lines(argv[2]);
   descriptors_closeall();
   descriptors_destroy();
   return 0;

}
