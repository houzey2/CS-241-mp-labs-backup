/**
 * password_cracker
 * CS 241 - Fall 2021
 */
#include "cracker2.h"
#include "format.h"
#include "utils.h"
#include "includes/queue.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <pthread.h>
#include <unistd.h>
#include <crypt.h>
#define FAILED 2;
#define FOUND 0;
#define CANCELLED 1;

typedef struct arg_thread {
    char* userName;
    char* hash;
    char* password;
} arg_thread;

pthread_barrier_t barrier;
arg_thread* args = NULL;
static pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
static int queue_size = 0;
static size_t num_thread = 0;
static int recovered = 0; 
static long total_count = 0;

void arg_destroy(arg_thread* arg){
    free(arg->userName);
    arg->userName = NULL;
    free(arg->hash);
    arg->hash = NULL;
    free(arg->password);
    arg->password = NULL;
    free(arg);
    arg = NULL;    
}

void* get_password(void* input) {
    if (input == NULL) {
	return NULL;
    }
    size_t id = (size_t)input;
    int count = queue_size;
    while(count > 0) {
	count--;
	//wait for args update
	pthread_barrier_wait (&barrier);
	char* userName = malloc(16); 
	strcpy(userName, args->userName);
	char* hash = malloc(16);
	strcpy(hash, args->hash);
	char* password= malloc(16);
	strcpy(password, args->password);
	int known_len = getPrefixLength(password);
	long start = 0;
	long count = 0;
	getSubrange(strlen(password) - known_len, num_thread,(int)id, &start, &count);
	char* unknow = password + known_len;
	//pthread_mutex_lock(&m);
	//printf("unknow is %s\n", unknow);
	setStringPosition(unknow, start);
	//printf("id is %zu, password is %s, start is %ld\n", id, password, start);
	//pthread_mutex_unlock(&m);
        struct crypt_data cdata;
        cdata.initialized = 0;
	long hashCount = 0;
	int result = FAILED;
	v2_print_thread_start(id, userName, start, password);
	while(1) {
	    hashCount++;
            char *hashed = crypt_r(password, "xx", &cdata);
	    if (strcmp(hash, hashed) == 0) {
		pthread_mutex_lock(&m);
	        recovered = 1;
		strcpy(args->password, password);
		pthread_mutex_unlock(&m);
		result = FOUND;
		break;
	    }
	    if (recovered == 1) {
		result = CANCELLED;
		break;
	    }
	    int add = incrementString(unknow);
	    if (add == 0 || hashCount == count) {
		//free(hashed);
	        break;
	    }
	    //free(hashed);
	}
	v2_print_thread_result(id, hashCount, result);
	pthread_mutex_lock(&m);
	total_count += hashCount;
	pthread_mutex_unlock(&m);
	free(userName);
        free(password);
	free(hash);
    	//lock, wait for next arg.
	pthread_barrier_wait (&barrier);
	//printf("end one loop\n");
    }
    //printf("end\n");
    return NULL;
}

int start(size_t thread_count) {
    // TODO your code here, make sure to use thread_count!
    // Remember to ONLY crack passwords in other threads
    pthread_t threads[thread_count];
    num_thread = thread_count;
    queue* queue_in  = queue_create(10000);
    //printf("number of thread is %zu\n", thread_count);
    size_t bufferSize = 32;
    while(1) {
	int characters;
        char* buffer;
	buffer = (char *)malloc(bufferSize * sizeof(char));
        characters = getline(&buffer,&bufferSize,stdin);
        //printf("buffer is %saaa\n", buffer);
	if (characters > 0) {
	    buffer[characters-1] = '\0';
	}
	if (characters < 0 || buffer[0] == '\n') {
	    free(buffer);
	    buffer = NULL;
	    break;
	}   
	queue_push(queue_in, buffer);
	queue_size++;
	buffer = NULL;
    }
    size_t i;
    pthread_barrier_init (&barrier, NULL, thread_count + 1);
    for (i = 0; i < thread_count; i++) {
	pthread_create(&threads[i], 0, get_password, (void*)(i + 1));
    }
    int count = queue_size;    
    //printf("count is %d\n", count);
    while(count > 0) {
	count--;
	char* string = queue_pull(queue_in);	
	args = malloc(sizeof(arg_thread));
        args->userName = malloc(16);
	args->hash = malloc(16);
	args->password = malloc(16);
	sscanf(string, "%s %s %s", args->userName, args->hash, args->password);
	free(string);

	double start_CPU = getCPUTime();
	double start_time = getTime();
    	v2_print_start_user(args->userName);
	//unlock other threads
	pthread_barrier_wait (&barrier);
	//lock to wait compute.
	pthread_barrier_wait (&barrier);
	double total_CPU_time = getCPUTime() - start_CPU;
	double total_time = getTime() - start_time;
	v2_print_summary(args->userName, args->password, total_count, total_time, total_CPU_time, !recovered);
	total_count = 0;
	recovered = 0;
	arg_destroy(args);
    }
    
    for(i = 0; i < thread_count; i++) {
	pthread_join(threads[i], NULL);
    }
    queue_destroy(queue_in);
    return 0; // DO NOT change the return code since AG uses it to check if your
              // program exited normally
}
