/**
 * password_cracker
 * CS 241 - Fall 2021
 */
#include "cracker1.h"
#include "format.h"
#include "utils.h"
#include "includes/queue.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <pthread.h>
#include <unistd.h>
#include <crypt.h>

// for backupi
static pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
static int fail = 0;
static int recovered = 0;
static queue* queue_in = NULL;
static int queue_size = 0;

void* get_password(void* input) {
    if (input == NULL) {
	return NULL;
    }
    size_t id = (size_t)input;
    //printf("id is %ld\n", id);i
    while(queue_size > 0) {
	//printf("loop start\n");
	pthread_mutex_lock(&m);
	//printf("queue size is %d\n", queue_size);
	queue_size -= 1;
        pthread_mutex_unlock(&m);
	if (queue_size < 0) {
	    break;
	}
	char* string = (char*)queue_pull(queue_in);
	char username[16];
	char hash[16];
	char password[16];	
	sscanf(string, "%s %s %s", username, hash, password);
	v1_print_thread_start(id, username);
	double start_time = getThreadCPUTime();
	
	int known_len =  getPrefixLength(password);
	char* unknow = password + known_len;
	setStringPosition(unknow, 0);
	struct crypt_data cdata;
        cdata.initialized = 0;
	int result = 1;
	int hashCount = 0;
	while(1) {
	    hashCount++;
	    //pthread_mutex_lock(&m);
	    const char *hashed = crypt_r(password, "xx", &cdata);
	    //pthread_mutex_unlock(&m);
	    //printf("hash is %saaa\n", hashed);
	    if (strcmp(hash, hashed) == 0) {
		pthread_mutex_lock(&m);
	        recovered++;
	        pthread_mutex_unlock(&m);
		result = 0;
		break;
	    }
	    int add = incrementString(unknow);
	    if (add == 0) {
		//printf("failed at %s\n", password);
	        pthread_mutex_lock(&m);
	        fail++;
	        pthread_mutex_unlock(&m);
		break;
	    }
	}
	double elapsed = getThreadCPUTime() - start_time;
	v1_print_thread_result(id, username, password, hashCount,elapsed,result);
	free(string);
	//printf("loop end\n");
    }
    return NULL;
}



int start(size_t thread_count) {
    
    // TODO your code here, make sure to use thread_count!
    // Remember to ONLY crack passwords in other threads
    queue_in  = queue_create(10000);
    //printf("number of thread is %zu\n", thread_count);
    size_t bufferSize = 32;

    while(1) {
	int characters;
        char* buffer;
	buffer = (char *)calloc(bufferSize, sizeof(char));
        characters = getline(&buffer,&bufferSize,stdin);
        //printf("buffer is %saaa\n", buffer);
	if (characters > 0) {
	    buffer[characters-1] = '\0';
	}
	if (characters < 0 || buffer[0] == '\n') {
	    free(buffer);
	    buffer = NULL;
	    break;
	}
		
	queue_push(queue_in, buffer);
	queue_size++;
	buffer = NULL;
    }
    /*if (queue_size < thread_count) {
	thread_count = queue_size;
    }*/
    size_t i;
    //printf("thread num %zu\n", thread_count);
    pthread_t threads[thread_count];
    for (i = 0; i < thread_count; i++) {
	size_t id_int = i + 1;
	pthread_create(&threads[i], 0, get_password, (void*)id_int);	
    }
    //printf("end 1\n");
    for(i = 0; i < thread_count; i++) {
	pthread_join(threads[i], NULL); 	
    }
    v1_print_summary(recovered, fail);
    queue_destroy(queue_in);
    //printf("return\n");
    return 0;
    // DO NOT change the return code since AG uses it to check if your
    // program exited normally
}
