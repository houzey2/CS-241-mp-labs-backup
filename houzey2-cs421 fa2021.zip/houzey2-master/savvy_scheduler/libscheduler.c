/**
 * savvy_scheduler
 * CS 241 - Fall 2021
 */

// Contributor: youlyu2, tw17, houzey2, zihanxu3.

#include "libpriqueue/libpriqueue.h"
#include "libscheduler.h"

#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "print_functions.h"

/**
 * The struct to hold the information about a given job
 */

int num;
double wait_time;
double response_time;
double turnaround_time;

typedef struct _job_info {
    int id;
    double create_time;
    double priority;
    double remaining;
    double start_time;
    double total_time;
    double first_start;
    /* TODO: Add any other information and bookkeeping you need into this
     * struct. */

} job_info;

void scheduler_start_up(scheme_t s) {
    switch (s) {
    case FCFS:
        comparision_func = comparer_fcfs;
        break;
    case PRI:
        comparision_func = comparer_pri;
        break;
    case PPRI:
        comparision_func = comparer_ppri;
        break;
    case PSRTF:
        comparision_func = comparer_psrtf;
        break;
    case RR:
        comparision_func = comparer_rr;
        break;
    case SJF:
        comparision_func = comparer_sjf;
        break;
    default:
        printf("Did not recognize scheme\n");
        exit(1);
    }
    priqueue_init(&pqueue, comparision_func);
    pqueue_scheme = s;
    // Put any additional set up code you may need here
}

static int break_tie(const void *a, const void *b) {
    return comparer_fcfs(a, b);
}

int comparer_fcfs(const void *a, const void *b) {
    // TODO: Implement me!
    job * job_a = (job*) a;
    job * job_b = (job*) b;
    job_info * a_meta = job_a->metadata;
    job_info * b_meta = job_b->metadata;
    if (a_meta->create_time < b_meta->create_time) {
        return -1;
    }
    return 1;
}

int comparer_ppri(const void *a, const void *b) {
    // Complete as is
    return comparer_pri(a, b);
}

int comparer_pri(const void *a, const void *b) {
    // TODO: Implement me!
    job * job_a = (job*) a;
    job * job_b = (job*) b;
    job_info * a_meta = job_a->metadata;
    job_info * b_meta = job_b->metadata;
    if (a_meta->priority == b_meta->priority) {
        return break_tie(a, b);
    } else if (a_meta->priority < b_meta->priority) {
        return -1;
    }
    return 1;

}

int comparer_psrtf(const void *a, const void *b) {
    // TODO: Implement me!
    job * job_a = (job*) a;
    job * job_b = (job*) b;
    job_info * a_meta = job_a->metadata;
    job_info * b_meta = job_b->metadata;
    if (a_meta->remaining == b_meta->remaining) {
        return break_tie(a, b);
    } else if (a_meta->remaining < b_meta->remaining) {
        return -1;
    }
    return 1;
}

int comparer_rr(const void *a, const void *b) {
    // TODO: Implement me!
    job * job_a = (job*) a;
    job * job_b = (job*) b;
    job_info * a_meta = job_a->metadata;
    job_info * b_meta = job_b->metadata;
    if (a_meta->start_time == b_meta->start_time) {
        return break_tie(a, b);
    } else if (a_meta->start_time < b_meta->start_time) {
        return -1;
    }
    return 1;
}

int comparer_sjf(const void *a, const void *b) {
    // TODO: Implement me!
    job * job_a = (job*) a;
    job * job_b = (job*) b;
    job_info * a_meta = job_a->metadata;
    job_info * b_meta = job_b->metadata;
    if (a_meta->total_time == b_meta->total_time) {
        return break_tie(a, b);
    } else if (a_meta->total_time < b_meta->total_time) {
        return -1;
    }
    return 1;
}

// Do not allocate stack space or initialize ctx. These will be overwritten by
// gtgo
void scheduler_new_job(job *newjob, int job_number, double time,
                       scheduler_info *sched_data) {
    // TODO: Implement me!
    job_info * new_job_info = calloc(1, sizeof(job_info));
    new_job_info->id = job_number;
    new_job_info->create_time = time;
    new_job_info->remaining = sched_data->running_time;
    new_job_info->total_time = sched_data->running_time;
    new_job_info->priority = sched_data->priority;
    new_job_info->start_time = -1;
    new_job_info->first_start = 0;
    newjob->metadata = new_job_info;
    priqueue_offer(&pqueue, newjob);
}

job *scheduler_quantum_expired(job *job_evicted, double time) {
    // TODO: Implement me!
    
    job* jobb = priqueue_peek(&pqueue);
    if (jobb == NULL && job_evicted == NULL) {
        return NULL;
    }

    job_info* job_infoo;

    if (job_evicted == NULL) {
        priqueue_poll(&pqueue);
        job_infoo = jobb->metadata;
        job_infoo->start_time = time;
        job_infoo->first_start = time;
        return jobb;
    }
    
    if (!(pqueue_scheme == RR || pqueue_scheme == PPRI || pqueue_scheme == PSRTF) && (job_evicted != NULL)) {
        job_infoo = job_evicted->metadata;
        perror("SIGINT Handler Registration Failed!");
        job_infoo->remaining -= time - job_infoo->start_time;
        return job_evicted;
    }
    
    
    
    if (pqueue_scheme == RR || pqueue_scheme == PPRI || pqueue_scheme == PSRTF) {
        job_infoo = job_evicted->metadata;
        job_infoo->remaining -= time - job_infoo->start_time;
        priqueue_offer(&pqueue, job_evicted);
        job* gogogo = priqueue_poll(&pqueue);
        job_infoo = gogogo->metadata;
        job_infoo->start_time = time;
        return gogogo;
    }

    
    
    
    return NULL;
}

void scheduler_job_finished(job *job_done, double time) {
    // TODO: Implement me!
    job_info* job_infoo = job_done->metadata;
    wait_time += time - job_infoo->create_time - job_infoo->total_time;
    response_time += job_infoo->first_start - job_infoo->create_time;
    turnaround_time += time - job_infoo->create_time;
    num = num + 1;
    free(job_infoo);
}

static void print_stats() {
    fprintf(stderr, "turnaround     %f\n", scheduler_average_turnaround_time());
    fprintf(stderr, "total_waiting  %f\n", scheduler_average_waiting_time());
    fprintf(stderr, "total_response %f\n", scheduler_average_response_time());
}

double scheduler_average_waiting_time() {
    // TODO: Implement me!
    return wait_time/num;
}

double scheduler_average_turnaround_time() {
    // TODO: Implement me!
    return turnaround_time/num;
}

double scheduler_average_response_time() {
    // TODO: Implement me!
    return response_time/num;
}

void scheduler_show_queue() {
    // OPTIONAL: Implement this if you need it!
}

void scheduler_clean_up() {
    priqueue_destroy(&pqueue);
    print_stats();
}
