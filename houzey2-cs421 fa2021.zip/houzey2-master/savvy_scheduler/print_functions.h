/**
 * savvy_scheduler
 * CS 241 - Fall 2021
 */
int int_write(int fd, int arg);
int double_write(int fd, double arg);
int ptr_write(int fd, void *arg);
