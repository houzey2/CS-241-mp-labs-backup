#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <stdio.h>
#include "camelCaser.h"
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>


int get_sentence_num(const char *input_str){
	if(!input_str){
		return 0;
	}
	//get the number of sentence
	//int size = strlen(input_str);
	int numPunct = 0;
	while(*input_str){
		if (ispunct(*input_str)) {
			numPunct++;
		}
		input_str++;
	}
	printf("num of sentence = %d\n",numPunct);
	return numPunct;
}
char **create_empty(int sentence_num, const char *input_str){
	char **output = malloc(sizeof(char*) * (sentence_num+1));// the starting
	output[sentence_num] = NULL;
	//bool isAlpha = false;
	int count = 0;
	int strSize = 0;
	while(*input_str) {
		if (!ispunct(*input_str) && !isspace(*input_str)){
			//current is alpha and not end, add length
			strSize++;
		}else if (ispunct(*input_str)){
			// current is punct
			output[count] = malloc(strSize + 1);
			output[count][strSize] = '\0';
			//printf("No.%d string is in size %d\n", count, strSize);
			count++;
			strSize = 0;
		}
		input_str++;
	}
	printf("new count is %d\n", count);
        //output[count] = malloc(strSize+1);
	//output[count][strSize] = '\0';
	return output;
}
char **camel_caser(const char *input_str) {
	// TODO: Implement me!
	if(!input_str){
		return NULL;
	}
	//get the number of sentence
	int count = get_sentence_num(input_str);
	if (count == 0) {
		char **output = malloc(sizeof(char*) * 1);
		output[0] = NULL;
		return output;
	}
	char **output = create_empty(count, input_str);
	// start cast
	bool needCap = false;
	int strlength = 0;
	int sentence = 0;
	while (*input_str){
         	//printf("current %c\n", *input_str);
		if (!isspace(*input_str)&&!ispunct(*input_str)) {
			// is char, write in output
			// the last char is space and it is not a start of sentence
			if (strlength > 0 && needCap) {
				output[sentence][strlength] = toupper(*input_str);
				needCap = false;
			}else {
				output[sentence][strlength] = tolower(*input_str);
			}
			strlength++;
		}else if (isspace(*input_str) && strlength > 0){
			// is space -> next Cap
			needCap = true;
		}else if (ispunct(*input_str)) {
			// is punct -> go to next sentence
			//output[sentence][strlength] = '\0';
			strlength = 0;
			sentence++;
			needCap = false;
			if (sentence >= count) {
			    break;
			}
		}
		input_str++;
	}
	return output;

}
void destroy(char **result) {
	// TODO: Implement me!

        int i = 0;
	for (i = 0; result[i]; i++) {
		free(result[i]);
	}
	free(result);
	return;
}
