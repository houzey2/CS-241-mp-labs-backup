/**
 * extreme_edge_cases
 * CS 241 - Fall 2021
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "camelCaser.h"
#include "camelCaser_tests.h"
int compare(char **result, char **correct){
    //printf("start compare");
    /*while(*result){
	if (*result == NULL) {
	    printf("NULL\n");
	}else {
	    printf("%s\n", *result);
	}
	result++;
    }*/
    if (result == NULL && correct == NULL) {
	return 1;
    } else if (result == NULL || correct == NULL) {
	return 0;
    }
    int i = 0;
    while(result[i]) {
        i++;
    }
    int j = 0;
    while(correct[j]) {
	j++;
    }
    if (i != j) {
	return 0;
    }
    printf("sizeCheck pass\n");
    for (i = 0; result[i]; i++) {
	//printf("to compare %s and %s", result[i], correct[i]);
	if (result[i] == NULL &&  correct[i] == NULL) {
	    continue;
	}else if (result[i] == NULL || correct[i] == NULL) {
	    return 0;
	}
        if (strcmp(result[i], correct[i])) {
	    printf("fail at %d\n", i);
	    return 0;
        }
    }
    
    return 1;
}

int test_camelCaser(char **(*camelCaser)(const char *),
                    void (*destroy)(char **)) {
    // TODO: Implement me!
    // test 0
    char *input = "hello. welcome to cs241";  
    char ** result = camelCaser(input);
    char *correct_0[] = {"hello", NULL};
    int check = compare(result, correct_0);
    if (!check) {
	return 0;
    }
    printf("case 0 success\n");
    destroy(result); 

    // test 1
    input = NULL;
    result = camelCaser(input);
    check = (result == NULL);
    if (!check) {
	return 0;
    }
    printf("case 1 success\n");
    
    // rest 2
    input = " ";
    result = camelCaser(input);
    char *correct_2[] = {NULL};
    check = compare(result, correct_2);
    if (!check){
        return 0;
    }
    printf("case 2 success\n");
    destroy(result);
    

    // test 3
    input = ".a   .";
    result = camelCaser(input);
    char *correct_3[] = {"", "a", NULL};
    check = compare(result, correct_3);
    if (!check) {
        return 0;
    }
    printf("case 3 success\n");
    destroy(result);

    // test 4
    input = ".. abc , edff fff, dd d.d";
    result = camelCaser(input);
    char * correct_4[] = {"", "", "abc", "edffFff", "ddD", NULL};
    check = compare(result, correct_4);
    if (!check) {
        return 0;
    }
    printf("case 4 success\n");
    destroy(result);

    // test 5
    input = ".....a a.";
    result = camelCaser(input);
    char * correct_5[] = {"","","","","","aA", NULL };
    check = compare(result, correct_5);
    if (!check) {
	return 0;
    }
    printf("case 5 success\n");
    destroy(result);

    // test 6
    input = "ab ab.....ab";
    result = camelCaser(input);
    char * correct_6[] = {"abAb", "", "", "", "", NULL};
    check = compare(result, correct_6);
    if (!check) {
	return 0;
    }
    printf("case 6 success\n");
    destroy(result);

    // test 7
    input = "result";
    result = camelCaser(input);
    char * correct_7[] = {NULL};
    check = compare(result, correct_7);
    if (!check) {
	return 0;
    }
    printf("case 7 success\n");
    destroy(result);
    
    // test 8
    input = "hELlo world.";
    result = camelCaser(input);
    char * correct_8[] = {"helloWorld", NULL};
    check = compare(result, correct_8);
    if (!check) {
	return 0;
    }
    printf("case 8 sucess\n");
    destroy(result);

    // test 9
    input = "      ";
    result = camelCaser(input);
    char * correct_9[] = {NULL};
    check = compare(result, correct_9);
    if (!check) {
	return 0;
    }
    printf("case 9 success\n");
    destroy(result);

    // test 10
    input = ",, ybb, , ybb010 ybybybb, tieguizongdeichuangsiyige";
    result = camelCaser(input);
    char * correct_11[] = {"", "", "ybb", "", "ybb010Ybybybb", NULL};
    check = compare(result, correct_11);
    if (!check) {
	return 0;
    }
    printf("case 10 success\n");
    destroy(result);

    // test 10
    input = "";
    result = camelCaser(input);
    char * correct_10[] = {NULL};
    check = compare(result, correct_10);
    if (!check) {
	return 0;
    }
    printf("case 10 success\n");
    destroy(result);
 
    
    // test 12
    input = "A, A. A; A: A) A( 10;";
    char * correct_12[] = {"a", "a", "a", "a", "a", "a", "10", NULL};
    result = camelCaser(input);
    check = compare(result, correct_12);
    if (!check) {
	return 0;
    }
    printf("case 12 sucess\n");

    // test 13
    input = "12, 10, , A11, 5";
    char * correct_13[] = {"12", "10", "", "a11", NULL};
    result =camelCaser(input);
    check = compare(result, correct_13);
    if (!check) {
	return 0;
    }
    printf("case 13 sucess\n");
    return 1;
}
