/**
 * extreme_edge_cases
 * CS 241 - Fall 2021
 */
#include <stdio.h>

#include "camelCaser_ref_utils.h"

int main() {
    // Enter the string you want to test with the reference here.
    char *input = NULL;
    // This function prints the reference implementation output on the terminal.
    print_camelCaser(input);
    char *input_5 = " ";
    print_camelCaser(input_5);
    char *input_6 = ".a   .";
    print_camelCaser(input_6);
    char *input_7 = ".. abc , edff fff, dd d.d";
    print_camelCaser(input_7);
    char *input_8 = ".....a a.";
    print_camelCaser(input_8);
    char *input_9 = "ab ab.....ab";
    print_camelCaser(input_9);
    char *input_10 = "result";
    print_camelCaser(input_10);
    char *input_1 = "hELlo world.";
    print_camelCaser(input_1);
    char *input_2 = "    ";
    print_camelCaser(input_2);
    char *input_3 = "aaa, bc123, 123b bba, ybb ybb* 10";
    print_camelCaser(input_3);
    char *input_4 = ",, ybb, , ybb010 ybybybb, tieguizongdeichuangsiyige";
    print_camelCaser(input_4);
    char *input_11 ="";
    print_camelCaser(input_11);
    char *input_12 = "A, A.A) A: A' A) 10;";
    print_camelCaser(input_12);
    char *input_13 = "12, 10,, A11, 5";
    print_camelCaser(input_13);  
    // Feel free to add more test cases.
    return 0;
}
