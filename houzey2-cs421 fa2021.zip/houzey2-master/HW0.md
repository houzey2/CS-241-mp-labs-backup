# HW0
### Q1
#### 1.1 
```c
#include <stdio.h> 
#include <unistd.h> 
int main() {
	write(1, "Hi! My name is Houze Yang", 25);
	return 0;
}
```
#### 1.2
```c
#include <stdio.h> 
#include <unistd.h> 
void write_triangle(int n) {
	int count;
	int cur;
	for (count = 0; count < n; count++){
		for (cur = count; cur >= 1; cur--){
			write(1, "*", 1);
		}
		write(1, "*\n", 2);
	}
}
```
#### 1.3
```c
#include <stdio.h> 
#include <unistd.h> 
int main() {
	mode_t mode = S_IRUSR | S_IWUSR;
	int fildes = open("hello_world.txt", O_CREAT | O_TRUNC | O_RDWR, mode);
	write(fildes, "Hello, World!", 14);
	close(fildes);
	return 0;
}
```
#### 1.4
```c
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>

int main() {
	mode_t mode = S_IRUSR | S_IWUSR;
	int fildes = open("hello_world.txt", O_CREAT | O_TRUNC | O_RDWR, mode);
	write(fildes, "Hello, World!", 14);
	printf("fildes is %d", fildes);
	close(fildes);
	return 0;
}
```
#### 1.5
write() is a system call that is run on kernal while printf() is an IO function in C standard library, and the implication of printf() may use write(). Also, printf() has a buffer that write() doesn't have.

### Q2
#### 2.1
There are 8 bits per byte
#### 2.2
1 byte in a char
#### 2.3
- int: 4 bytes
- double: 8 bytes 
- float: 4 bytes  
- short: 2 bytes 
- long: 4 bytes  
- long long: 8 bytes
#### 2.4
0x7fbd9d50
#### 2.5
data+3

### Q3
#### 3.1
we can either print out value of argc to get the size of argv or we can use a for loop to count the number of elements in argv.
#### 3.2
argv[0] represent ./program
#### 3.3 
The pointers of environment variable are stored at the top of the processor and above stack memory 
#### 3.4
sizeof(ptr) = 8 \
sizeof(array) = 6
#### 3.5
It is determined by the life time of the function, which means when the function is returned, the variable get freed automatically.
### Q4
#### 4.1
We can either use the key word static to make this variable a global variable or we can use malloc to ask the process for memory in heap to store the variable in heap memmory.
#### 4.2
Heap memory is growing up, which means the hex number of memory will getting larger as we store more variable. Stack memory is growing down, that as we add new variable in stack, the hex address decrease. The stack memory are temporary memory and it will automatically free after the function end. However, heap is a global memory and won't be automatically deleted.
#### 4.3
the memory to store environment variable.
#### 4.4
In a good C program, for every malloc, there is a free.
#### 4.5
It is possible that the malloc can't give too many bytes then it will give back an invalid pointer to null or nothing.
#### 4.6
time() will return the current time in time_t while c time can return the time as char*.
#### 4.7
it free the pointer for two times, and will make the process crash.
#### 4.8
it try to print the string stored at ptr after free it, which is nothing in fact.
#### 4.9
Set the value to NULL after free it.
#### 4.10
```c
struct Person {
	char* name;
	int age;
	struct Person** friends;
}

typedef struct Person person_t;
```
#### 4.11
```c
int main() {
	person_t* ptr1 = malloc(sizeof(person_t));
	person_t* ptr2 = malloc(sizeof(person_t));
	ptr1->name = "Agent Smith";
	ptr1->age = 128;
	ptr1->friends = malloc(sizeof(person_t));
	ptr1->friends[0] = ptr2;
	ptr2->name = "Sonny Moore";
	ptr2->age = 256;
	ptr2->friends = malloc(sizeof(person_t));
	ptr2->friends[0] = ptr1;
	free(ptr1->friends);
	free(ptr2->friends);
	free(ptr1);
	free(ptr2);
	return 0;
}
```
#### 4.12
```c
person_t* create(char* name, int age){
	person_t* ptr1 = malloc(sizeof(person_t));
	ptr1->name = malloc(sizeof(name));
	ptr1->name = name;
	ptr1->age = age;
	return ptr1;
};
```
#### 4.13
```c
void destory(person_t input){
	free(input->name);
	free(input->friends);
	free(input);
}

```
### Q5
#### 5.1
getchar();
#### 5.2
if the input string is overflow, then when we try to get it, it may take the place of previous variable and change its value.
#### 5.3
```c
int main() {
	char* data = "Hello 5 World";
	char buffer_1[6];
	int num = 0;
	char buffer_2[6];
	
	int result = sscanf(data, "%s %d %s", buffer_1, &num, buffer_2);
	printf("Result:%d, %s, %d, %s", result, buffer_1, num, buffer_2);
	return 0;
}
```
#### 5.4
#define _GUN_SOURCE
#### 5.5
```c
int main() {
	char *buffer = NULL;
	size_t capacity = 0;
	size_t result = getline( &buffer, &capacity, stdin);
	int cur_p = 0;
	int start = 0;
	char* toPrint[sizeof(buffer)];
	while (buffer[start + cur_p - 1]){
		cur_p++;
		if (buffer[cur_p] == '\n'){
			printf("%s\n",toPrint);
			start = cur_p;
			cur_p = 0;
			memset(toPrint, 0, sizeof(toPrint));
		}else{
			toPrint[cur_p] = buffer[start + cur_p - 1];
		}
	}
	
	return 0;
}
```
### C Development
#### 1
-g with -o
#### 2
Because it was in debug build rather than letting the complier to generate a new build.
#### 3
We can't indented with space and have to use tab
#### 4
git commit will record the change you made to the git repository\n
commit with key word sha means the commit can not be changed because sha1 is an algorithm that will generate a 40-digit hex number depend on the input.
#### 5
git log shows a record of commit in git repository
#### 6
git status let us see which change have been staged, which not, and which filed is ignored. In this case, we can see the files which is ignored through status.
#### 7 
git push will update remote repository using local repository while git commit will update code from index to local repository. If we do not push the code to remote repository, others can neither pull your code nor fetch the code.
#### 8
git may can't make change in remote repository without losing commit. For example, if someone else pushed to the same branch as us, then git won't push our commit. In this case, we can use fetching and merging to fix this problem.
