//worked by houzey2

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <signal.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>

ssize_t read_all_from_socket(int socket, char *buffer, size_t count) {
    // Your Code Here
    ssize_t total_count = 0;
    while (total_count < (ssize_t)count) {
        int bytes = read(socket, buffer + total_count, count - total_count);
        if (bytes > 0) {
            total_count += bytes;
        } else if (bytes == 0) {
            break;
        } else {
            if (errno != EINTR) {
                return -1;
            }
        }
    }
    return total_count;
}

ssize_t write_all_to_socket(int socket, const char *buffer, size_t count) {
    // Your Code Here
    ssize_t total_count = 0;
    while (total_count < (ssize_t)count) {
        int bytes = write(socket, buffer + total_count, count - total_count);
        if (bytes > 0) {
            total_count += bytes;
        } else if (bytes == 0) {
            break;
        } else {
            if (errno != EINTR) {
                return -1;
            }
        }
    }
    return total_count;
}

int main(int argc, char **argv) {
    if (argc != 4) {
        printf("usage\n");
        exit(1);
    }
    if (strcmp(argv[0], "./search") != 0) {
	exit(1);
    }
    int start, end;
    sscanf(argv[2], "%d", &start);
    sscanf(argv[3], "%d", &end);
    if (start < 0 || end < 0 || end < start) {
	exit(1);
    }
    char *host = argv[1];
    int sock_fd = socket(AF_INET, SOCK_STREAM, 0); 
    for (int i = start; i < end; i++) {
	char port[1024];
       	sprintf(port, "%d", i);
	//printf("%s\n", port);
	struct addrinfo hints, *result;
        memset(&hints, 0, sizeof(struct addrinfo));
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_STREAM;

	int s = getaddrinfo(host, port, &hints, &result);
        if (s) {
            fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s));
            exit(1);
        }
	if (connect(sock_fd, result->ai_addr, result->ai_addrlen)) {
	    printf("%c", '.');
	    continue;
	}
	freeaddrinfo(result);	
	//printf("%s connected\n", port);
	char *arg_write = "GET /HTTP/1.0\r\n\r\n";
	ssize_t count = write_all_to_socket(sock_fd, (const char*) arg_write, strlen(arg_write));
	shutdown(sock_fd, SHUT_WR);
	char response[1024];
    	memset(response, 0, 1024);
    	count = read_all_from_socket(sock_fd, response, strlen("200"));
	//printf("response is %s\n", response);
	if (strcmp(response, "200") == 0) {
	    printf("%s", port);
	    shutdown(sock_fd, SHUT_RD);
	    close(sock_fd);
	    exit(0);
	}
	printf("%c", '.');
	shutdown(sock_fd, SHUT_RD);
	close(sock_fd);
    }
}
