//worked by houzey2
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <linux/random.h>
#include <unistd.h>

int main(int argc, char **argv) {
    if (argc != 3) {
        printf("Hello World");
        exit(0);
    }
    if (strcmp(argv[0], "./encrypt") == 0) {
        //printf("encrypt\n");
        const char* input = argv[1];
        //read origin file size
	//printf("filename is %s\n", input);
        struct stat attrib;
        int state = stat(input, &attrib);
	    if (state == -1) {
		//printf("unavaliable file\n");
		printf("Hello World");
		exit(0);
	    }
        size_t size = attrib.st_size;
        //printf("size is %zu\n", size);
	// read and overwirte origin file
        int ori_fd = open(input, O_RDWR);
        if (ori_fd == -1) {
            //printf("can't open the file");
	    printf("Hello World");
	    exit(0);
        }
        void *read_ori = mmap(NULL, size, PROT_READ|PROT_WRITE, MAP_SHARED, ori_fd, 0);
        if (read_ori == MAP_FAILED) {
	    //printf("cant read\n");
            printf("Hello World");
            exit(0);
        }       
	char* ori_cpy = calloc(size, 1);
	memcpy(ori_cpy, read_ori, size);
	//auto fill
	memset(read_ori, 0xff, size);
	close(ori_fd);
        //printf("read is %s", ori_cpy);
	// get random
	int randomData = open("/dev/urandom", O_RDONLY);	
	char read_random[size];
        memset(read_random, 0, size);	
	if (randomData < 0){
    	    //printf("cant open random\n");
	    printf("Hello World");
	    exit(0);
	} else{
	    ssize_t result = read(randomData, read_random, size);
    	    if (result == -1){
        	//printf("cant read random\n");
		printf("Hello World");
		exit(0);
    	    }
        }
	close(randomData);
	//printf("random is %s with size %zu\n", read_random, sizeof(read_random));
	FILE* write_file = fopen(argv[2], "w");
	for (size_t i = 0; i < size; i++) {
	    fputc(read_random[i], write_file);
	}
	for (size_t i = 0; i < size; i++) {
	    fputc(read_random[i] ^ *ori_cpy, write_file);
	    ori_cpy++;
	}
	fclose(write_file);
	free(ori_cpy - size);
	exit(0);
    } else if (strcmp(argv[0], "./decrypt") == 0) {
        //printf("decrypt\n");
	const char* input = argv[1];
        //read origin file size
	//printf("filename is %s\n", input);
        struct stat attrib;
        int state = stat(input, &attrib);
	    if (state == -1) {
		//printf("unavaliable file\n");
		printf("Hello World");
		exit(0);
	    }
        size_t size = attrib.st_size;
        //printf("size is %zu\n", size);
	// read and overwirte origin file
        int ori_fd = open(input, O_RDWR);
        if (ori_fd == -1) {
            //printf("can't open the file");
	    printf("Hello World");
	    exit(0);
        }
        void *read_ori = mmap(NULL, size, PROT_READ|PROT_WRITE, MAP_SHARED, ori_fd, 0);
        if (read_ori == MAP_FAILED) {
	    //printf("cant read\n");
            printf("Hello World");
            exit(0);
        }       
	char* ori_cpy = calloc(size, 1);
	memcpy(ori_cpy, read_ori, size);
	//auto fill
	close(ori_fd);
	remove(input);
	unlink(input);
        //printf("read is %s\n", ori_cpy);
	// get random
	size_t write_size = size / 2;
	char* encoded = ori_cpy + write_size;
	FILE* write_file = fopen(argv[2], "w");
	for (size_t i = 0; i < write_size; i++) {
	    fputc(*encoded ^ *ori_cpy, write_file);
	    ori_cpy++;
	    encoded++;
	}
	fclose(write_file);
	free(ori_cpy - write_size);
	exit(0);
    } else {
        printf("He`llo World");
        exit(0);
    }
}
