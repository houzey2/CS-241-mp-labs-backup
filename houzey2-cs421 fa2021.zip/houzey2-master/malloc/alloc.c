/**
 * malloc
 * CS 241 - Fall 2021
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#define TOL 0.5
#define IGNORE 1024


typedef struct _meta_data {
    // Number of bytes of heap memory the user requested from malloc
    size_t size;
    ///void *ptr;
    int used;
    // Pointer to the next instance of meta_data in the list
    struct _meta_data *next;
    //struct _meta_data *next_free;
    struct _meta_data *prev;
} meta_data;


static meta_data *head = NULL; // under 1024
static size_t total_freed = 0;

void merge(meta_data* start) {
    //fprintf(stderr, "merge\n");  
    
    size_t size = start->prev->size + sizeof(meta_data);
    start->prev = start->prev->prev;
    //fprintf(stderr, "stop 1\n");
    if (start->prev != NULL) {
	start->prev->next = start;
    } else {
        head = start;
    }
    //fprintf(stderr, "stop 2\n");
    start->size += size; 
    total_freed += sizeof(meta_data);
}
void split(meta_data* start, size_t size) {
    //fprintf(stderr, "split\n");
    //fprintf(stderr, "two size are same? %d\n", start->size == size);
    void* ptr = (void*) (start + 1);
    meta_data* newBlock = ptr + size;
    //fprintf(stderr, "getNext\n");
    //fprintf(stderr, "newBlock->size %p\n", newBlock);
    newBlock->size = start->size - size - sizeof(meta_data);
    //fprintf(stderr, "getsize\n");
    total_freed += newBlock->size;
    //newBlock->ptr = newBlock + 1;
    newBlock->used = 0;
    newBlock->next = start;
    newBlock->prev = start->prev;
    if (start->prev == NULL) {
	// at start
        head = newBlock;	
    }else {
	// in the middle
        start->prev->next = newBlock;
    }
    start->prev = newBlock;
    start->size = size;
    //fprintf(stderr, "split done\n");
    if (newBlock->prev != NULL && newBlock->prev->used == 0) {
	merge(newBlock);
    }   
}
/*
size_t power_two(size_t size) {
    size_t p = 1;
    while (p < size){
        p <<= 1;
    }
    return p;    
}
int validFind(size_t size, size_t chosen_size) {
    if (size < chosen_size && chosen_size <= IGNORE) {
        return 1;
    }
    double waste = (double)(chosen_size - size) / (double) chosen_size;
    if (chosen_size > size && waste > TOL) {
        return 0;
    }
    return 1;
}
*/
void *calloc(size_t num, size_t size) {

    size_t request_size = num * size;
    void* output = malloc(request_size);
    if (output == NULL) {
	return NULL;
    }
    //fprintf(stderr, "add_size is %zu\n", add_size);
    memset(output, 0, request_size);
    return output;
}

void *malloc(size_t size) {
    // implement malloc!
    //fprintf(stderr, "malloc\n");
    if (size < 0) {
	return NULL;
    }

    meta_data* itr = head; 
    meta_data* toAdd = NULL;
    //size_t size_2 = power_two(size); 
    if (size <= total_freed && size >= sizeof(int)){
        while(itr) {  
            if (itr->size >= size && itr->used == 0) {
                toAdd = itr;
		if (itr->size < size + sizeof(meta_data)) {
		   break;
		} else { 
		    split(toAdd, size);
		    break; 
		}
            }
            itr = itr->next;
    	}
    }
    
    if (toAdd) {
	//fprintf(stderr, "malloc : case 1\n");
	toAdd->used = 1;
	total_freed -= toAdd->size;
	return (void*)(toAdd + 1);
    }
    //fprintf(stderr, "new\n");
    //fprintf(stderr, "malloc : case 2\n");
    toAdd = sbrk(sizeof(meta_data) + size);
    // check if sbrk works
    if (toAdd == (void*)-1) {
        return NULL;
    }    
    //toAdd->ptr = toAdd + 1;
    toAdd->size = size;
    toAdd->used = 1;
    // add toAdd to used list
    if (head == NULL) {
        toAdd->next = NULL;
        toAdd->prev = NULL;
        head = toAdd;
    } else {
        toAdd->next = head;
        head->prev = toAdd;
	toAdd->prev = NULL;
	head = toAdd;
    }
    return (void*)(toAdd + 1);     
}
void free(void *ptr) {
    // implement free!
    //backup
    //
    //fprintf(stderr, "free\n");
    if (ptr == NULL) {
	return;
    }
    meta_data* input = ((meta_data*)ptr) - 1;
    if (input->used == 0) {
	return;
    }
    //fprintf(stderr, "valid input\n");
    input->used = 0;
    total_freed += input->size;   
    if (input->prev != NULL && input->prev->used == 0) {
        merge(input);	
    } 
    if (input->next != NULL && input->next->used == 0) {
	merge(input->next);
    }
    //fprintf(stderr, "end\n");    
}

void *realloc(void *ptr, size_t size) {
    // implement realloc!
    //fprintf(stderr, "realloc\n");
    if (ptr == NULL && size == 0) {
	return NULL;
    } else if (ptr == NULL) {
	return malloc(size);
    } else if (size == 0) {
	free(ptr);
	return NULL;
    }
    //size_t size = power_two(size);
    meta_data* target = ((meta_data*)ptr) - 1;   
    if (target->size == size) {
	return ptr;
    }
     
    size_t old_size = target->size;
    void *newPtr = NULL;
    //fprintf(stderr, "old %zu, and new %zu\n", old_size, size);
    if (old_size < size) {
        if (target->prev != NULL && target->prev->used == 0 && target->prev->size + old_size + sizeof(meta_data) >= size) {
	    //fprintf(stderr, "realloc : case 1\n");
	    merge(target);
	    if (old_size >= size + sizeof(meta_data)) {
		split(target, size);
	    }
	    return ptr;
	} else {
	    //fprintf(stderr, "realloc : case 2\n");
	    newPtr = malloc(size);
	    memcpy(newPtr, ptr, old_size);
	    free(ptr);
	    return newPtr;
	}      
    } else {
        if (old_size >= size +  sizeof(meta_data)) {
	    //fprintf(stderr, "realloc : case 3\n");
	    split(target, size);
	    return ptr;
	}
	return ptr;
    }
}
