/**
 * charming_chatroom
 * CS 241 - Fall 2021
 */
#pragma once

int my_read(int fd, void *buff, size_t count);