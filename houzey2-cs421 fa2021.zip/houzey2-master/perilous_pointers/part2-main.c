/**
 * perilous_pointers
 * CS 241 - Fall 2021
 */
#include "part2-functions.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * (Edit this function to print out the "Illinois" lines in
 * part2-functions.c in order.)
 */
int main() {
    // your code here
    int value_1 = 81;
    first_step(value_1);

    int* value_2 = malloc(sizeof(int));
    value_2[0] = 132;
    second_step(value_2);
    free(value_2);

    int** value_3 = malloc(sizeof(int*));
    value_3[0] = malloc(sizeof(int));
    value_3[0][0] = 8942;
    double_step(value_3);
    free(value_3[0]);
    free(value_3);

    int i = 15;
    char *value_4 = (char*) &(i) - 5;
    strange_step(value_4);

    int j = 0;
    void *value_5 = (void*) &(j) - 3;
    empty_step(value_5);
    
    char *s2 = "000u";
    void *s = s2;
    two_step(s, s2);

    char *first = "12222222";
    char *second = first + 2;
    char *third = second + 2;
    three_step(first, second, third);

    char *first_1 = "008@";
    char *second_1 = first_1;
    char *third_1 = first_1;
    step_step_step(first_1, second_1, third_1);    

    char *a = "1";
    int b = 49;
    it_may_be_odd(a, b);

    char str[] = "this,CS241,aa";
    tok_step(str);

    char result[] = {1, 2, 0, 0};
    void* orange = result;
    void* blue = result;
    the_end(orange, blue);
    return 0;

}
