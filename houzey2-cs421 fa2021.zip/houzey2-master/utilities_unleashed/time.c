/**
 * utilities_unleashed
 * CS 241 - Fall 2021
 */
#include <time.h>
#include "format.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
int main(int argc, char *argv[]) {
    if (argc <= 1) {
	print_time_usage();
    }
    pid_t childid = fork();

    if (childid < 0) {
        // fork fail
        print_fork_failed();
    } else  if (childid > 0) {
	//parent
        struct timespec start;
        int a = clock_gettime(CLOCK_MONOTONIC, &start);
        int status;
        waitpid(childid, &status, 0);
        struct timespec end;
        int b = clock_gettime(CLOCK_MONOTONIC, &end);	
	if (a != 0 || b != 0) {
            print_exec_failed();
	}
	double time = end.tv_sec - start.tv_sec + (end.tv_nsec - start.tv_nsec) / 1000000000.0;
        if (status == 0){
            display_results(argv, time);
	}
    } else {
	// child
        int status = execvp(*(argv + 1), argv + 1);
	if (status != 0 ) {
            print_exec_failed();
	    exit(1);
	}
    }


    return 0;
}
