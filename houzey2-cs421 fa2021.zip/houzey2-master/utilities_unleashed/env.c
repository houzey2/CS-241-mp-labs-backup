/**
 * utilities_unleashed
 * CS 241 - Fall 2021
 */
#include "format.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>
#include <stdlib.h> 
int split(char *input, char **output) {
    //printf("split\n");
    int i;
    int delimiter = 0;
    int cur = 0;
    int size = (int)strlen(input);
    char* toAdd = calloc(size, sizeof(char));
    int canHave = 0;
    for (i = 0; input[i]; i++) {
      //printf("%c \n", input[i]);
      if (!isdigit(input[i]) && !isalpha(input[i]) && input[i] != '=' && input[i] != '_' && (canHave && input[i] != '%')) {
        // invalid input
        //printf("out1\n");
        return 0;
      } else if (input[i] == '=' && (delimiter == 1 || i == 0 || i == size - 1)) {
        // more than one '=' or '=' is at the start or end
        //printf("out2\n");
        return 0;
      }  else if (input[i] == '=') {
        //printf("add\n");
        delimiter++;
        strcpy(output[cur], toAdd);
        free(toAdd);
        toAdd = calloc(size, sizeof(char));
        cur++;
        canHave = 1;
        //printf("endadd\n");
      } else {
        //printf("add one\n");
        canHave = 0;
        toAdd = strncat(toAdd, input + i, 1);
      }
    }
    strcpy(output[cur], toAdd);
    free(toAdd);
    return delimiter == 1;
}

int main(int argc, char *argv[]) {
  //printf("argc = %d\n", argc);
    if (argc < 3) {
        print_env_usage();
    }
    pid_t childid = fork();
    if (childid < 0) {
	print_fork_failed();
    } else if (childid > 0) {
	int status;
	waitpid(childid, &status, 0);
    } else if (childid == 0) {
	int i;
        for (i = 1; i < argc; i++) {
            if (strcmp(argv[i], "--") == 0) {
		break;
	    }
	}
	if (i >= argc - 1) {
	    // invalid --
	    print_env_usage();
	}
    	for (i = 1; i < argc; i++) {
            if (strcmp(argv[i], "--") == 0) {
                break;
            } else {
                char** output = calloc(2, sizeof(char*));
     	        output[0] = calloc(strlen(argv[i]), sizeof(char));
      	        output[1] = calloc(strlen(argv[i]), sizeof(char));
		int j = split(argv[i], output);
      	        // printf("output[0] = %s\n", output[0]);
		// printf("output[1] = %s\n", output[1]);
		// printf("valid or not: %d\n", j);
                if (j == 0) {
		    print_env_usage();
		}
                if (output[1][0] != '%') {
		    int success = setenv(output[0], output[1], 1);
		    if (success != 0) {
			print_environment_change_failed();
		    }
		} else {
		    // is a reference
		    char* previous = getenv(output[1] + 1);
		    if (previous == NULL) {
	       		free(output[0]);
	       		free(output[1]);
			free(output);
			print_environment_change_failed();
		    }
		    int sucess = setenv(output[0], previous, 1);
		    if (sucess != 0) {
	
		       	free(output[0]);
	       		free(output[1]);
			free(output);
 			print_environment_change_failed();
		    }
		}
	       	free(output[0]);
	       	free(output[1]);
		free(output);
            }
	    
       }
       //printf("current index = %d\n", i);
       //printf("%s\n", *(argv + i + 1));
       int status = execvp(*(argv + i + 1), argv + i + 1);	
       if (status != 0) {
           print_exec_failed();
           exit(1);
       }
      
    }
    return 0;
}
