/**
 * vector
 * CS 241 - Spring 2021
 */
#include "vector.h"
#include <stdio.h>
#include <stdbool.h>


int main(int argc, char *argv[]) {
    
   
    return 0;
}
