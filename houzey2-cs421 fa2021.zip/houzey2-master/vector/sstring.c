/**
 * vector
 * CS 241 - Fall 2021
 */
#include "sstring.h"
#include "vector.h"

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <assert.h>
#include <string.h>

struct sstring {
    // Anything you want
    char* string;
    size_t size;
};

sstring *cstr_to_sstring(const char *input) {
    // your code goes here
    sstring *toReturn = malloc(sizeof(sstring));
    toReturn->size = strlen(input);
    toReturn->string = malloc(toReturn->size + 1);
    toReturn->string[toReturn->size] = '\0';
    size_t i;
    for (i = 0; i < toReturn->size; i++) {
	toReturn->string[i] = input[i];
    }
    return toReturn;
}

char *sstring_to_cstr(sstring *input) {
    // your code goes here
    size_t size = input->size;
    char* toReturn = malloc(size + 1);
    toReturn[size] = '\0';
    size_t i;
    for (i = 0; i < size; i++) {
        toReturn[i] = input->string[i];
    }
    return toReturn;
}

int sstring_append(sstring *this, sstring *addition) {
    // your code goes here
    size_t temp_size = this->size;
    this->size += addition->size;
    char *temp = this->string;
    this->string = malloc(this->size + 1);
    this->string[this->size] = '\0';
    size_t i;
    for (i = 0; i < temp_size; i++) {
	this->string[i] = temp[i];
    }
    for (i = 0; i < addition->size; i++) {
	this->string[i + temp_size] = addition->string[i];
    }
    free(temp);
    return (int)this->size;

}

vector *sstring_split(sstring *this, char delimiter) {
    // your code goes here
    vector* toReturn = string_vector_create();
    vector* subString = char_vector_create();
    char* iterate = this->string;
    while(*iterate) {
	if (*iterate != delimiter) {
            vector_push_back(subString, iterate);
	} else {
	    size_t size = vector_size(subString);
	    char* toAdd = malloc(size + 1);
	    toAdd[size] = '\0';
	    size_t i;
	    for (i = 0; i < size; i++) {
		toAdd[i] = *(char*)vector_get(subString, i);
	    }
	    vector_clear(subString);
	    vector_push_back(toReturn, toAdd);
	    free(toAdd);
	}
	iterate++;
    }
    size_t size = vector_size(subString);
    char* toAdd = malloc(size + 1);
    toAdd[size] = '\0';
    size_t i;
    for (i = 0; i < size; i++) {
	toAdd[i] = *(char*)vector_get(subString, i);
    }
    vector_clear(subString);
    vector_push_back(toReturn, toAdd);
    free(toAdd);
    vector_destroy(subString);
    return toReturn;
}
int sstring_substitute(sstring *this, size_t offset, char *target,
                       char *substitution) {
    // your code goes here
    char* string = this->string;
    size_t strsize = 0;
    size_t length = strlen(target);
    int detect = -1;
    string += offset;
    int i = 0;
    while(*string) {
	      if (!strncmp(string, target, length)) {
            detect = 0;
            i++;
            string+=length;
	      }else{
	          string++;
	      }
    }  
    string = this->string;
    int max_size = strlen(this->string) + strlen(substitution) * i;
    printf("substitution: %d\n", max_size);
    char *result = calloc(max_size + 1, sizeof(char));
    if (offset > 0) {
        strncat(result, string, offset);
    }
    //chenggongde
    printf("result = %s\n", result);
    string+=offset;
    char* before = string;
    while(*string) {
	      if (!strncmp(string, target, length)) {
            //printf("sub is :%s\n", result);
            //printf("toAdd : %s\n", before);
                  strncat(result, before, strsize);
            //printf("add length = %d\n", (int)strsize);
	         // printf("result = %s\n", result);
		 // printf("substitution = %s\n", substitution);
		  strcat(result, substitution);
		 // printf("result = %s\n", result);
            //printf("result = %s\n", result);
	          strsize = 0;
                  string+=length;
	          before = string;
            //printf("the rest is : %s\n", before);
	      }else{
	          strsize++;
	          string++;
	      }
    
    }
   // printf("before is %s\n", before);
   // printf("strsize = %zu\n", strsize);
    strcat(result, before);
   // printf("result is %s\n", result);
    result[max_size] = '\0';
    this->string = strcpy(this->string, result);
    this->size = strlen(this->string);
   // printf("this->string :%s\n", this->string);
    free(result);
    return detect;
}

char *sstring_slice(sstring *this, int start, int end) {
    // your code goes here
    if (start < 0 || end >= (int)this->size) {
        printf("unavaliable index\n");
	return NULL;
    }
    char *toReturn = malloc(end - start + 1);
    int i;
    for (i = start; i < end; i++) {
	toReturn[i - start] = this->string[i];
    }
    toReturn[end-start] = '\0';
    return toReturn;
}

void sstring_destroy(sstring *this) {
    free(this->string);
    free(this);
    // your code goes here
}
