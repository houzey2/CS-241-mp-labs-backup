/**
 * vector
 * CS 241 - Fall 2021
 */
#include "sstring.h"

int main(int argc, char *argv[]) {
    return 0;
}
