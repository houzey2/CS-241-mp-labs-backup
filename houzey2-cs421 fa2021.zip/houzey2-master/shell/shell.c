/**
 * shell
 * CS 241 - Fall 2021
 */
#include "format.h"
#include "shell.h"
#include "vector.h"
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include "callbacks.h"
#include "sstring.h"
#include "vector.h"
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/resource.h>
#include <fcntl.h>
#include <sys/stat.h>
// input argumen:ts
#define None 0
#define History 1
#define File 2
#define Both 3

// operator mode
#define Normal 0
#define Output 1
#define Append  2
#define Input 3
typedef struct process {
    char *command;
    pid_t pid;
} process;
int shunter(char* input, vector* record, int shouldAdd, int mode, char* target, vector* pid_vector, vector* command_vector);

int solve_kill(char* pid, vector* pid_vector, vector* command_vector){
    //printf("pid is %s\n", pid);
    size_t size = vector_size(pid_vector);
    int target = atoi(pid);
    //printf("size is %zu\n", size);
    if (size == 0) {
	print_no_process_found(target);
	return 0;
    } 
    size_t i;
    struct stat buffer;
    int status;
    char str[1024];
    sprintf(str, "/proc/%d", target);
    status = stat(str, &buffer);
    if (status != 0) {
	print_no_process_found(target);
        return 0;
    }
    for (i = 0; i < size; i++) {
	char* command = vector_get(command_vector, i);
	//printf("command_vector%s\n", command);
	int pid_int = *(int*)vector_get(pid_vector, i);
	if (target == pid_int) {
	// find target
            //printf("aaa%sbbb", command);
	    int ret = kill(pid_int, SIGKILL);
            if (ret == -1) {
		return 0;
	    }	    
	    print_killed_process(pid_int, command);
	    //vector_erase(pid_vector, i);
	    //vector_erase(command_vector, i);
	    int status;
            waitpid(-1, &status, WNOHANG);

	    return 1;
	}
	//printf("pid is %d\n", pid_int);
    }
    print_no_process_found(target);
    return 0;
}

int solve_stop(char* pid, vector* pid_vector, vector* command_vector){
    //printf("pid is %s\n", pid);
    size_t size = vector_size(pid_vector);
    int target = atoi(pid);
    //printf("size is %zu\n", size);
    if (size == 0) {
	print_no_process_found(target);
	return 0;
    }
    struct stat buffer;
    int status; 
    char str[1024];
    sprintf(str, "/proc/%d", target);
    status = stat(str, &buffer);
    if (status != 0) {
	print_no_process_found(target);
        return 0;
    }
    size_t i;
    for (i = 0; i < size; i++) {
	char* command = vector_get(command_vector, i);
	//printf("command_vector%s\n", command);
	int pid_int = *(int*)vector_get(pid_vector, i);
	if (target == pid_int) {
	// find target
            //printf("aaa%sbbb", command);
	    int ret = kill(pid_int, SIGSTOP);
            if (ret == -1) {
		return 0;
	    }	    
	    print_stopped_process(pid_int, command);
	    //vector_erase(pid_vector, i);
	    //vector_erase(command_vector, i);
	    return 1;
	}
	//printf("pid is %d\n", pid_int);
    }
    print_no_process_found(target);
    return 0;
}

int solve_cont(char* pid, vector* pid_vector, vector* command_vector){
    //printf("pid is %s\n", pid);
    size_t size = vector_size(pid_vector);
    int target = atoi(pid);
    //printf("size is %zu\n", size);
    if (size == 0) {
	print_no_process_found(target);
	return 0;
    }
    struct stat buffer;
    int status;
    char str[1024];
    sprintf(str, "/proc/%d", target);
    status = stat(str, &buffer);
    if (status != 0) {
	print_no_process_found(target);
        return 0;
    }
    size_t i;
    for (i = 0; i < size; i++) {
	char* command = vector_get(command_vector, i);
	//printf("command_vector%s\n", command);
	int pid_int = *(int*)vector_get(pid_vector, i);
	if (target == pid_int) {
	// find target
            //printf("aaa%sbbb", command);
	    int ret = kill(pid_int, SIGCONT);
            if (ret == -1) {
		return 0;
	    }	    
	    print_continued_process(pid_int, command);
	    //vector_erase(pid_vector, i);
	    //vector_erase(command_vector, i);
	    return 1;
	}
	//printf("pid is %d\n", pid_int);
    }
    print_no_process_found(target);
    return 0;
}

char* remove_space(char* input) {
    while(*input) {
        if (*input == ' ') {
	    input++;
	}else {
	    break;
	}
    }
    size_t len = strlen(input);
    int index;
    for (index = (int)len - 1; index >= 0; index--) {
	if (input[index] == ' ') {
	    input[index] = '\0';
	} else {
	    break;
	}
    }
    return input;
}
int solve_ps(vector* pid_vector, vector* command_vector) {
    //printf("solve ps\n");
    int status;
    waitpid(-1, &status, WNOHANG);
    size_t size = vector_size(pid_vector);
    size_t i;
    for (i = 0; i < size; i++) {
	pid_t pid = *(int*)vector_get(pid_vector, i);
	char* command = (char*)vector_get(command_vector, i);
	//printf("end 1\n");
        struct stat buffer;
        int status; 
        char str[1024];
        sprintf(str, "/proc/%d", pid);
        status = stat(str, &buffer);
        if (status != 0) {
	    continue;
        }
	char filename[1024];
	sprintf(filename, "/proc/%d/stat", pid);
        FILE* file_f = fopen(filename,"r");
	vector* file_read = vector_create(string_copy_constructor, string_destructor, string_default_constructor);
	//printf("start read\n");
	char* read;
	int count = 0;
	while (1){
	    
	    size_t readsize = 2048;
	    read = (char *)calloc(readsize,  sizeof(char));
	    size_t characters;
	    characters = getline(&read, &readsize, file_f);
	    if (!read[0]) {
		//printf("end\n");
		fclose(file_f);
		free(read);
		//printf("size is %d\n", count);
		break;
	    }
	    if (characters > 0) {
	        read[characters - 1] = '\0';
	    }
 	    //printf("input is %s\n", read);
	    vector_push_back(file_read, read);
	    free(read);
	    read = NULL;
	    count++;
	}	
  	//printf("end 2\n");	
        char* result = vector_get(file_read, 0);
	sstring* output = cstr_to_sstring(result);
	vector* split = sstring_split(output, ' ');	
	
	process_info* info = malloc(sizeof(process_info));
	info->pid = (int)pid;
	info->nthreads = (long int)atoi((char*)(vector_get(split, 19)));
	info->vsize = (unsigned long int)atoi((char*)(vector_get(split, 22))) / 1024;
	info->state = ((char*)vector_get(split, 2))[0];
        //printf("end 3\n");
	FILE* fp = fopen("/proc/stat", "r");
	//printf("start read\n");
	char* read_2;
	time_t btime = 0;
	vector* gettime = NULL;
	while (1){
	    //printf("end3.1\n");
	    size_t readsize = 100;
	    read_2 = (char *)calloc(readsize,  sizeof(char));
	    size_t characters;
	    characters = getline(&read_2, &readsize, fp);
	    if (!read_2[0]) {
		//printf("end\n");
		fclose(fp);
		free(read_2);
		break;
	    }
	    //printf("stop here\n");
	    if (characters > 0) {
	        read_2[characters - 1] = '\0';
	    }
            //printf("stop here2\n");
 	    if (strncmp(read_2, "btime", 5) == 0) {
		
		sstring* boot = cstr_to_sstring(read_2);
		gettime = sstring_split(boot, ' ');
		sstring_destroy(boot);
		btime = (time_t)atoi((char*)(vector_get(gettime, 1))); 

		break;
	    }
	    free(read_2);
	    read = NULL;
	    //printf("end3.2\n");
	}
	//printf("end4\n");
	time_t start =(time_t)atoi((char *)vector_get(split, 21)) / sysconf(_SC_CLK_TCK);
	time_t total = start + btime;
	struct tm *timeinfo = localtime (&total);	
	
	char time_str[100];
	time_struct_to_string(time_str, 100, timeinfo);
	info->start_str = time_str;
        
	time_t utime = (time_t)atoi((char*)vector_get(split, 13)) / sysconf(_SC_CLK_TCK);
        time_t stime = (time_t)atoi((char*)vector_get(split, 14)) / sysconf(_SC_CLK_TCK);
	char time_str2[100];
	execution_time_to_string(time_str2, 100, (utime + stime)/60, (utime + stime)%60);
	
	info->time_str = time_str2;
	info->command = command;
	print_process_info(info);
	
	
	vector_destroy(split);
	sstring_destroy(output);
	free(info);
	vector_destroy(gettime);
	vector_destroy(file_read);
    }
    return 1;
}


int solve_external(vector* input, int mode, char* target, int wait, vector* pid_vector) {
    size_t size = vector_size(input);
    char **arguments = calloc(sizeof(char*), size+1);
    size_t i;
    //printf("size is %zu\n",size);
    for (i = 0; i < size; i++) {
        char *item = (char*) vector_get(input, i);
	//printf("item is :%s\n", item);
        arguments[i] = item;
    }
    //printf("get the char** filled\n");
    pid_t pid = fork();
    if (pid < 0) {
        print_fork_failed();
        return 0;
    } else if (pid > 0) {
        int status = 0;	
 	
	//printf("size is %zu\n", vector_size(processes));
	if (wait == 0) {
            waitpid(pid, &status, 0);
	} else if (wait == 1) {
	    vector_push_back(pid_vector, &pid);
	    waitpid(-1, &status, WNOHANG);
	}
        //vector_destroy(input);
	free(arguments);
	arguments = NULL;
	return (status == 0);
	//printf("exec finish \n");
    } else if (pid == 0) {	
        pid_t childid = getpid();
        print_command_executed(childid);

	FILE * write = NULL;
	FILE * read = NULL;
	int stdout_copy;
	int stdin_copy;
	//int stdin_copy;
        if (mode != Normal) {
	    //printf("target is %s\n", target);
	    //printf("command is %s\n", *(arguments))i;
	    if (target == NULL) {
		print_redirection_file_error();
		exit(1);
	    }
	    if (mode == Output || mode == Append) {
		//printf("write mode");
	        stdout_copy = dup(1);
                close(1);
	        if (mode == Output) {
 	            write = fopen(target, "w");
	        } else if (mode == Append) {
		    write = fopen(target, "a");
	        }
	        if (!write) {
	            print_redirection_file_error();
	            exit(1);
	        }      
	    } else {
	        //printf("input mode \n");
		stdin_copy = dup(0);
		close(0);
		//read = open(target, O_RDONLY);
		read = fopen(target, "r");
		if (!read) {
	            print_redirection_file_error();
	            exit(1);
	        }
	    }
	}
        int status = execvp(*(arguments), arguments);
        if (status != 0) {
    	    print_exec_failed(*(arguments));
       	    exit(1);
        }
    }
    return 0;   
}

int solve_cd(vector* input) {
    //pid_t pid = getpid();
    //print_command_executed(pid);
    char *arg = vector_get(input, 1);
    int result = chdir(arg);
    if (result != 0) {
	print_no_directory(arg);
	//vector_destroy(input);
	return 0;
    }
    return 1;
   
}
int solve_history(vector* record){
    //pid_t pid = getpid();
    //print_command_executed(pid);
    if (record == NULL) {
	return 0;
    }
    size_t size = vector_size(record);
    size_t i;
    for(i = 0; i < size; i++) {
	char* command = (char*)vector_get(record, i);
	print_history_line(i, command);
    }
    return 1;
}
int solve_num(vector* input, vector* record, vector* pid_vector, vector* command_vector) {
    size_t size = vector_size(record);
    char* command = (char*) vector_get(input, 0);
    int index = atoi(command + 1);
    //printf("index is %zu\n", (size_t)index);
    if (index >= (int)size || index < 0) {
	print_invalid_index();
	return 0;
    }
    char *command_to_run = vector_get(record, index);
    print_command(command_to_run);
    //vector_destroy(input);
    return shunter(command_to_run, record, 1, Normal, NULL, pid_vector, command_vector);    
}
int solve_prefix(char* input, vector* record, vector* pid_vector, vector* command_vector) {
    char* prefix = input + 1;
    size_t subsize = strlen(prefix);
    size_t size = vector_size(record);
    if (size < 1) {
	print_no_history_match();
	return 0;
    }
    int i;
    int match = 0;
    //printf("before last\n");
    char* command_to_run = (char*) vector_get(record, size - 1);
    //printf("after last\n");
    for (i = size - 1; i >= 0; i--) {
	command_to_run = (char*) vector_get(record, i);
	if (strncmp(prefix, command_to_run, subsize) == 0) {
	    match = 1;
	    break;
	}	
    }
    if (!match) {
	print_no_history_match();
	return 0;
    }
    print_command(command_to_run);
    return shunter(command_to_run, record, 1, Normal, NULL, pid_vector, command_vector);
}

int solve_and(char* input, vector* record, vector* pid_vector, vector* command_vector) {
    sstring* to_split = cstr_to_sstring(input);
    vector* split = sstring_split(to_split, '&');
    size_t size = vector_size(split);
    if ((int)size != 3) {
        print_invalid_command(input);
	sstring_destroy(to_split);
	vector_destroy(split);
	return 0;
    }
    char* command_1 = vector_get(split, 0);
    //printf("command_1 is %s\n", command_1);
    char* command_2 = vector_get(split, size - 1);
    //printf("command_2 is %s\n", command_2);
    int status_1 = shunter(command_1, record, 0, Normal, NULL, pid_vector, command_vector);
    if (status_1 == 0) {
	sstring_destroy(to_split);
	vector_destroy(split);
	return 0;
    }
    int status_2 = shunter(command_2, record, 0, Normal, NULL, pid_vector, command_vector);
    sstring_destroy(to_split);
    vector_destroy(split);
    return (status_2 != 0);
}
int solve_or(char* input, vector* record, vector* pid_vector, vector* command_vector) {
    sstring* to_split = cstr_to_sstring(input);
    vector* split = sstring_split(to_split, '|');
    size_t size = vector_size(split);
    if ((int)size != 3) {
        print_invalid_command(input);
	sstring_destroy(to_split);
	vector_destroy(split);
	return 0;
    }
    char* command_1 = vector_get(split, 0);
    //printf("command_1 is %s\n", command_1);
    char* command_2 = vector_get(split, size - 1);
    //printf("command_2 is %s\n", command_2);
    int status_1 = shunter(command_1, record, 0, Normal, NULL, pid_vector, command_vector);
    if (status_1 == 1) {
	sstring_destroy(to_split);
	vector_destroy(split);
	return 1;
    }
    int status_2 = shunter(command_2, record, 0, Normal, NULL, pid_vector, command_vector);
    sstring_destroy(to_split);
    vector_destroy(split);
    return (status_2 != 0);
}
int solve_sep(char* input, vector* record, vector* pid_vector, vector* command_vector) {
    sstring* to_split = cstr_to_sstring(input);
    vector* split = sstring_split(to_split, ';');
    size_t size = vector_size(split);
    if ((int)size != 2) {
        print_invalid_command(input);
	sstring_destroy(to_split);
	vector_destroy(split);
	return 0;
    }
    char* command_1 = vector_get(split, 0);
    //printf("command_1 is %s\n", command_1);
    char* command_2 = vector_get(split, size - 1);
    //printf("command_2 is %s\n", command_2);
    shunter(command_1, record, 0, Normal, NULL, pid_vector, command_vector);
    shunter(command_2, record, 0, Normal, NULL, pid_vector, command_vector);
    sstring_destroy(to_split);
    vector_destroy(split);	
    return 1;
 
}

int solve_output(char* input, vector* pid_vector, vector* command_vector) {
    //printf("solve output\n");
    sstring* to_split = cstr_to_sstring(input);
    vector* split = sstring_split(to_split, '>');
    size_t size = vector_size(split);
    if ((int)size != 2) {
	print_invalid_command(input);
	sstring_destroy(to_split);
	vector_destroy(split);
	return 0;
    }
    char* command_1 = vector_get(split, 0);
    char* target = vector_get(split, size - 1);
    command_1 = remove_space(command_1);
    //printf("command_1 is %s\n", command_1);    
    target = remove_space(target);
    //printf("target is %s\n", target);
    sstring_destroy(to_split);
    
    int output =  shunter(command_1, NULL, 0, Output, target, pid_vector, command_vector);
    vector_destroy(split);
    return output;
}
int solve_append(char* input, vector* pid_vector, vector* command_vector) {
    //printf("solve append\n");
    sstring* to_split = cstr_to_sstring(input);
    vector* split = sstring_split(to_split, '>');
    size_t size = vector_size(split);
    if ((int)size != 3) {
	print_invalid_command(input);
	sstring_destroy(to_split);
	vector_destroy(split);
	return 0;
    }
    char* command_1 = vector_get(split, 0);
    char* target = vector_get(split, size - 1);
    command_1 = remove_space(command_1);
    //printf("command_1 is %s\n", command_1);    
    target = remove_space(target);
    //printf("target is %s\n", target);
    sstring_destroy(to_split);
    int output =  shunter(command_1, NULL, 0, Append, target, pid_vector, command_vector);
    vector_destroy(split);
    return output;
}
int solve_input(char* input, vector* pid_vector, vector* command_vector) {
    //printf("solve input\n"); 

    sstring* to_split = cstr_to_sstring(input);
    vector* split = sstring_split(to_split, '<');    
    size_t size = vector_size(split);
    if ((int)size != 2) {
	print_invalid_command(input);
	sstring_destroy(to_split);
	vector_destroy(split);
	return 0;
    }
    char* command_1 = vector_get(split, 0);
    char* target = vector_get(split, size - 1);
    command_1 = remove_space(command_1);
    // printf("command_1 is %s\n", command_1);    
    target = remove_space(target);
    //printf("target is %s\n", target);
    sstring_destroy(to_split); 
   
    int output = shunter(command_1, NULL, 0, Input, target, pid_vector, command_vector);
    //printf("size of process after add is %zu\n", vector_size(processes));
 
    vector_destroy(split);
    return output;
}
int shunter(char* input, vector* record, int shouldAdd, int mode, char* target, vector* pid_vector, vector* command_vector) {   
    //case of eof
    // deal with sapce at the start:
    
    if (shouldAdd != 0){
    	vector_push_back(record, input);
    } 
    //printf("point 1\n");
   
    //printf("original command is %saaa\n", input);
    while(*input) {
	if (*input == ' ') {
	    input++;
	}else {
	    break;
	}
    }
    size_t len = strlen(input);
    int index;
    for (index = (int)len - 1; index >= 0; index--) {
	if (input[index] == ' ') {
	    input[index] = '\0';
	} else {
	    break;
	}
    }
    if (input[0] == 0) {
	return 1;
    }
    if (strstr(input, "&&") != NULL) {
	return solve_and(input, record, pid_vector, command_vector);
    } else if (strstr(input, "||") != NULL) {
	return solve_or(input, record, pid_vector, command_vector);
    } else if (strstr(input, ";") != NULL) {
	return solve_sep(input, record, pid_vector, command_vector);
    } else if (strstr(input, ">>") != NULL) {
	return solve_append(input, pid_vector, command_vector);
    } else if (strstr(input, ">") != NULL) {
	return solve_output(input, pid_vector, command_vector);
    } else if (strstr(input, "<") != NULL) {
	return solve_input(input, pid_vector, command_vector);
    }
    else {
	sstring* command_ss = cstr_to_sstring(input);
        vector *input_command = sstring_split(command_ss, ' ');
	sstring_destroy(command_ss);
        char *command = (char*) vector_get(input_command, 0);
	size_t size = vector_size(input_command);
	int isnum = 1;
	char *itr = command + 1;
	while(*itr) {
	    if (isdigit(*itr) == 0) {
	        isnum = 0;
		break;
	    }
	    itr++;
	}
	
	if (command[0] == '#' && size == 1 && isnum == 0) {
	    if (atoi(command + 1) != 0) {
		isnum = 1;
	    }
	}
        char * end = vector_get(input_command, size - 1);
	if (strcmp(end, "&") == 0) {
	    vector_pop_back(input_command);
	    vector_push_back(command_vector, input);
	    int output = solve_external(input_command, mode, target, 1, pid_vector);
	    vector_destroy(input_command);
	    return output;
	    // run background
	} else if (strcmp(command, "ps") == 0) {
	    int output = solve_ps(pid_vector, command_vector);
            vector_destroy(input_command);
	    return output;
	    // run ps	    
	} else if (strcmp(command, "cd") == 0) {
	    int output = solve_cd(input_command);
	    vector_destroy(input_command);
	    return output;
            // run cd
        } else if (strcmp(command, "!history") == 0 && size == 1) {
	    //vector_push_back(record, input);
	    vector_pop_back(record);
	    int output = solve_history(record);
	    vector_destroy(input_command);
	    return output;
               // run history
        } else if (command[0] == '#' && size == 1 && isnum != 0) {
	    vector_pop_back(record);
	    int output = solve_num(input_command, record, pid_vector, command_vector);
	    vector_destroy(input_command);
	    return output;
	    // run #<n>
        } else if (command[0] == '!') {
	    vector_pop_back(record);
	    int output = solve_prefix(input, record, pid_vector, command_vector);
	    vector_destroy(input_command);
	    return output;
	    // run #prefix
        } else if (strcmp(command, "kill") == 0) {
	    //printf("kill\n");
	    if (size != 2) {
		//printf("size is %zu\n", size);
		print_invalid_command(input);
		vector_destroy(input_command);
		return 0;
    	    }
    	    char* pid = vector_get(input_command, 1);
	    int isPid = 1;
            while(*pid) {
                if (isdigit(*pid) == 0) {
	            isPid = 0;
	            break;
                }
                pid++;
            }
	    if (atoi(pid) != 0) {
		isPid = 1;
	    }
	    if (isPid == 0) {
		print_invalid_command(input);
		vector_destroy(input_command);
		return 0;
	    }
	    pid = vector_get(input_command, 1);
	    int output = solve_kill(pid, pid_vector, command_vector);
	    vector_destroy(input_command);
	    return output;
	} else if (strcmp(command, "stop") == 0) {
	    //printf("stop\n");
	    if (size != 2) {
		//printf("size is %zu\n", size);
		print_invalid_command(input);
		vector_destroy(input_command);
		return 0;
    	    }
    	    char* pid = vector_get(input_command, 1);
	    int isPid = 1;
            while(*pid) {
                if (isdigit(*pid) == 0) {
	            isPid = 0;
	            break;
                }
                pid++;
            }
	    if (atoi(pid) != 0) {
		isPid = 1;
	    }
	    if (isPid == 0) {
		print_invalid_command(input);
		vector_destroy(input_command);
		return 0;
	    }
	    pid = vector_get(input_command, 1);
	    int output = solve_stop(pid, pid_vector, command_vector);
	    vector_destroy(input_command);
	    return output;
	} else if (strcmp(command, "cont") == 0) {
	    //printf("cont\n");
	    if (size != 2) {
		//printf("size is %zu\n", size);
		print_invalid_command(input);
		vector_destroy(input_command);
		return 0;
    	    }
    	    char* pid = vector_get(input_command, 1);
	    int isPid = 1;
            while(*pid) {
                if (isdigit(*pid) == 0) {
	            isPid = 0;
	            break;
                }
                pid++;
            }
	    if (atoi(pid) != 0) {
		isPid = 1;
	    }
	    if (isPid == 0) {
		print_invalid_command(input);
		vector_destroy(input_command);
		return 0;
	    }
	    pid = vector_get(input_command, 1);
	    int output = solve_cont(pid, pid_vector, command_vector);
	    vector_destroy(input_command);
	    return output;	
        } else {
	    //printf("size of process before add is %zu\n", vector_size(processes));
	    int output = solve_external(input_command, mode, target, 0, pid_vector);
	    //printf("size of process after add is %zu\n", vector_size(processes)); 
	    vector_destroy(input_command);
	    return output;
	    // run external command	
        }
    }	
}


// print prompt given file nam
void prompt(char* input){  
    char* path = get_full_path(input);
    pid_t pid = getpid(); 
    print_prompt(path, pid);
    free(path);  
}

void sigintHandler(){
    kill(0, 0);
    printf("\n");
}

int shell(int argc, char *argv[]) {
    struct rlimit limit;
    limit.rlim_cur = 100;
    limit.rlim_max = 200;
    setrlimit(RLIMIT_NPROC, &limit);
    // TODO: This is the entry point for your shell.
    int mode; 
    if (argc != 1 && argc != 3 && argc != 5 ) {
	// incorrect string length
	//print_usage();
	return 0;
    }
    if (argc == 1) {
	mode = None;
    }
    if (argc == 3 && (strcmp(argv[1], "-h") != 0 && strcmp(argv[1], "-f") != 0)) {
	print_usage();
	return 0;
    }else if (argc == 3 && strcmp(argv[1], "-h") == 0) {
	mode = History;
    } else if (argc == 3) {
        mode = File;
    }
    if (argc == 5 && ((strcmp(argv[1], "-h") != 0 && strcmp(argv[1], "-f") != 0) || (strcmp(argv[3], "-h") != 0 && strcmp(argv[3], "-f") != 0) || (strcmp(argv[1], argv[3]) == 0))){
	print_usage();
	return 0;
    }else if (argc == 5){
        mode = Both;
    }

    //start shell
    vector* record = vector_create(string_copy_constructor, string_destructor, string_default_constructor);
    vector* pid_vector = vector_create(int_copy_constructor, int_destructor, int_default_constructor);
    pid_t pid = getpid();
    vector_push_back(pid_vector, &pid);
    vector* command_vector = vector_create(string_copy_constructor, string_destructor, string_default_constructor);
    vector_push_back(command_vector, argv[0]);
    int max_path = 200;
    char path[max_path]; 		
    signal(SIGINT, sigintHandler);   
    char* buffer;
    if (mode == None || mode == History) {
	while(1){
	    getcwd(path, max_path);
	    prompt(path);
            //printf("history or nothing");
            size_t bufsize = 128;
            int characters;
            buffer = (char *)calloc(bufsize, sizeof(char));
            characters = getline(&buffer,&bufsize,stdin);
	    //printf("input is  %s\n", buffer);   
	    if (characters > 0) {
	    	buffer[characters-1] = '\0';
	    }
	   // printf("characters is %d\n", characters);
	    if (characters < 0 || strcmp(buffer, "exit") == 0) {
		if (characters < 0) {
		    printf("\n");
		}
		if (mode == History) {
		    char* fileName = argv[2];
		    FILE * file_h = fopen(fileName, "a");
		    //int fputs( const char *s, FILE *fp );
		    size_t size  = vector_size(record);
		    size_t i = 0;
		    for (i = 0; i < size; i++) {
			char* to_write = vector_get(record, i);
			fputs(to_write, file_h);
			if (strcmp(to_write, "\0") != 0) {
			    fputs("\n", file_h);
			}
		    }
		    fclose(file_h);
		}
                free(buffer);
		buffer = NULL;
	        vector_destroy(record);
		vector_destroy(pid_vector);
		vector_destroy(command_vector);
	        exit(0);
		return 0;
    	    }
            //printf("buffer is \n"); 
            shunter(buffer, record, 1, Normal, NULL, pid_vector, command_vector);
	    free(buffer);
	    buffer = NULL;
	}
    } else if (mode == File || mode == Both) {
	char* fileName_f;
	char* fileName_h;
	if (mode == File) {
	    fileName_f = argv[2];
	} else {
	    if (strcmp(argv[1], "-h") == 0) {
		fileName_f = argv[4];
		fileName_h = argv[2];
	    } else {
		fileName_f = argv[2];
		fileName_h = argv[4];
	    }
	}
	FILE* file_f = fopen(fileName_f,"r");
	vector* file_read = vector_create(string_copy_constructor, string_destructor, string_default_constructor);
	//printf("start read\n");
	char* read;
	while (1){
	    size_t readsize = 128;
	    read = (char *)calloc(readsize,  sizeof(char));
	    size_t characters;
	    characters = getline(&read, &readsize, file_f);
	    if (!read[0]) {
		//printf("end\n");
		fclose(file_f);
		free(read);
		break;
	    }
	    if (characters > 0) {
	        read[characters - 1] = '\0';
	    }
 	    //printf("input is %s\n", read);
	    vector_push_back(file_read, read);
	    free(read);
	    read = NULL;
	}
	size_t i;
	size_t num = vector_size(file_read);
	for(i = 0; i < num; i++) {
	    getcwd(path, max_path);
	    prompt(path);
	    char *command = vector_get(file_read, i);
	    if (strcmp(command, "exit") == 0) {
		//printf("finished\n");
		break;
	    }
	    if (strcmp(command, "\n") == 0) {
		continue;
	    }
	    print_command(command);
	    shunter(command, record, 1, Normal, NULL, pid_vector, command_vector);
	}
	if (mode == Both) {
	    FILE * file_h = fopen(fileName_h, "a");
	    //int fputs( const char *s, FILE *fp );
	    size_t size  = vector_size(record);
	    size_t i = 0;
	    for (i = 0; i < size; i++) {
		char* to_write = vector_get(record, i);
		fputs(to_write, file_h);
		if (strcmp(to_write, "\n") != 0) {
		    fputs("\n", file_h);
		}
	    }
	    fclose(file_h);
	}
        vector_destroy(record);
	vector_destroy(pid_vector);
	vector_destroy(command_vector);
        vector_destroy(file_read);

    }
         
   
    return 0;
}
