/**
 * shell
 * CS 241 - Fall 2021
 */
#include "shell.h"

// Seperate main file used for grading. Do not modify!
int main(int argc, char **argv) {
    // calls the student code
    shell(argc, argv);
}
