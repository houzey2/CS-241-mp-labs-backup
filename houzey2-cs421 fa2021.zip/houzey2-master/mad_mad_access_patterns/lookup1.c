/**
 * mad_mad_access_patterns
 * CS 241 - Fall 2021
 * Contributor: tkimura4, tw17, houzey2, jiahuiw4, weixia3, xuningh2
 */
#include "tree.h"
#include "utils.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
/*
  Look up a few nodes in the tree and print the info they contain.
  This version uses fseek() and fread() to access the data.

  ./lookup1 <data_file> <word> [<word> ...]
*/

int search(FILE * file, char * word, long offset) {
  
  fseek(file, offset, SEEK_SET);
  BinaryTreeNode tn;
  fread(&tn, sizeof(BinaryTreeNode), 1, file);

  // find the word
  fseek(file, offset+16, SEEK_SET);
  char file_word[4096];
  fread(file_word, 4096, 1, file);

  // compare the word
  int cmp = strcmp(word, file_word);
  if(cmp == 0) {
    printFound(word, tn.count, tn.price);
    return 0;
  } else if (cmp > 0) {
    if(tn.right_child) {
      return search(file, word, tn.right_child);
    } else {
      return -1;
    }
  } else if (cmp < 0) {
    if(tn.left_child) {
      return search(file, word, tn.left_child);
    } else {
      return -1;
    }
  }
  return -1;
}

int main(int argc, char **argv) {
  // argument error message
  if(argc < 3) {
    printArgumentUsage();
    exit(1);
  }

  char * data_file = argv[1];
  FILE * file = fopen(data_file, "r");
  if(!file) {
    openFail(data_file);
    exit(2);
  }
  // seek
  fseek(file, 0, SEEK_SET);
  char buf[4];
  fread(buf, 4, 1, file);
  if(strcmp(buf, BINTREE_HEADER_STRING)) {
    openFail(data_file);
    exit(2);
  }
  for(int i = 2; i < argc; i++) {
    // search
    // printf("%s\n", argv[i]);
    int result = search(file, argv[i], 4);
    if(result == -1) {
      printNotFound(argv[i]);
    }
  }
  fclose(file);
  return 0;
}
