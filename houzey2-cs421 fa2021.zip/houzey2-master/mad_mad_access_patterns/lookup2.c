/**
 * mad_mad_access_patterns
 * CS 241 - Fall 2021
 * Contributor: tkimura4, tw17, houzey2, jiahuiw4, weixia3, xuningh2
 */
#include "tree.h"
#include "utils.h"
#include <sys/mman.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

/*
  Look up a few nodes in the tree and print the info they contain.
  This version uses mmap to access the data.

  ./lookup2 <data_file> <word> [<word> ...]
*/

int search(char * file_string, char * word, long offset) {
  BinaryTreeNode * node = (BinaryTreeNode *)(file_string + offset);
  int cmp = strcmp(word, node->word);
  if(cmp == 0) {
    printFound(word, node->count, node->price);
    return 0;
  } else if (cmp > 0) {
    if(node->right_child) {
      return search(file_string, word, node->right_child);
    } else {
      return -1;
    }
  } else if (cmp < 0) {
    if(node->left_child) {
      return search(file_string, word, node->left_child);
    } else {
      return -1;
    }
  }
  return -1;
}

int main(int argc, char **argv) {
  if(argc < 3) {
    printArgumentUsage();
    exit(1);
  }
  char * data_file = argv[1];
  FILE * file = fopen(data_file, "r");
  int fd = fileno(file);
  if(!file) {
    openFail(data_file);
    exit(2);
  }

  struct stat curr;  
  // check if the current rule is a file 
  int statFlag = stat(data_file, &curr);
  if(statFlag != 0)  {
    openFail(data_file);
    exit(2);
  }

  //mmap(addr, len, prot, flags, fildes, off);
  char * file_string = mmap(NULL, curr.st_size, PROT_READ, MAP_PRIVATE, fd, 0);

  if(file_string == MAP_FAILED) {
    mmapFail(data_file);
    exit(3);
  }

  if(strncmp(file_string, BINTREE_HEADER_STRING, 4)) {
    openFail(data_file);
    exit(2);
  }

  for(int i = 2; i < argc; i++) {
    int flag = search(file_string, argv[i], 4);
    if(flag == -1) {
      printNotFound(argv[i]);
    }
  }

  return 0;
}

